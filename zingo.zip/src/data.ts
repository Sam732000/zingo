import { MenuItem } from './types';

export const KITCHEN_LAT = 22.7208;
export const KITCHEN_LNG = 88.4809;

export const PACKAGING_FEE = 10;
export const FREE_DELIVERY_RADIUS_KM = 3;
export const MIN_CART_FOR_FREE_DELIVERY = 299;
export const BELOW_MIN_DELIVERY_FEE = 35;
export const PER_KM_FEE_BEYOND_RADIUS = 20;

export const WA_NUMBER = '917477444755';
export const INSTAGRAM_URL = 'https://www.instagram.com/zingo.129?igsh=OWd6ams3a2Z5dWd5';
export const FACEBOOK_URL = 'https://www.facebook.com/share/1DZUL5XTSv/';
export const GEOAPIFY_API_KEY = 'c7cffd41c3144ac5a44237483053b297';

export const MENU: MenuItem[] = [
  // Appetizers
  { id: 'a1', cat: 'Appetizers', veg: true, nm: 'French Fries Salted', ds: 'Classic salted fries', pr: 69, emoji: '🍟' },
  { id: 'a2', cat: 'Appetizers', veg: true, nm: 'Firecracker Peri Fries', ds: 'Peri-peri tossed crunch fries', pr: 79, emoji: '🍟' },
  { id: 'a3', cat: 'Appetizers', veg: false, nm: 'Chicken Nuggets (5 pc)', ds: 'Golden fried chicken nuggets', pr: 89, emoji: '🍗' },
  { id: 'a4', cat: 'Appetizers', veg: false, nm: 'Chicken Finger (5 pc)', ds: 'Crispy chicken fingers', pr: 99, emoji: '🍗' },
  { id: 'a5', cat: 'Appetizers', veg: false, nm: 'Chicken Cheese Bombs (4 pc)', ds: 'Cheese-stuffed chicken bombs', pr: 99, emoji: '💣' },
  { id: 'a6', cat: 'Appetizers', veg: true, nm: 'Cheese Golden Corn (5 pc)', ds: 'Crispy cheese-corn bites', pr: 89, emoji: '🌽' },
  { id: 'a7', cat: 'Appetizers', veg: true, nm: 'Cheese Bomb Pops (5 pc)', ds: 'Molten cheese pops', pr: 89, emoji: '🧀' },
  { id: 'a8', cat: 'Appetizers', veg: true, nm: 'Cheese Volcano Fries', ds: 'Fries erupting with molten cheese', pr: 99, best: true, emoji: '🌋' },

  // Pocket Pizza
  { id: 'p1', cat: 'Pocket Pizza', veg: false, nm: 'K-Town Chicken Pocket', ds: 'Korean-style chicken pocket pizza', pr: 99, emoji: '🍕' },
  { id: 'p2', cat: 'Pocket Pizza', veg: false, nm: 'Smoky Sausage Pocket', ds: 'Smoked sausage & melted cheese', pr: 99, emoji: '🍕' },
  { id: 'p3', cat: 'Pocket Pizza', veg: true, nm: 'Tandoori Paneer Pocket', ds: 'Tandoori spiced paneer pocket', pr: 99, emoji: '🍕' },
  { id: 'p4', cat: 'Pocket Pizza', veg: true, nm: 'The Garden Crunch Pocket', ds: 'Loaded veggie pocket pizza', pr: 89, emoji: '🍕' },
  { id: 'p5', cat: 'Pocket Pizza', veg: true, nm: 'Triple Cheese Lava Pocket', ds: 'Three-cheese molten pocket', pr: 99, emoji: '🍕' },
  { id: 'p6', cat: 'Pocket Pizza', veg: false, nm: 'Chicken Tikka Pocket Pizza', ds: 'Chicken tikka stuffed pocket pizza', pr: 99, best: true, emoji: '🍕' },

  // Burger & Sandwich
  { id: 'b1', cat: 'Burger & Sandwich', veg: false, nm: 'K-Town Crunch Burger', ds: 'Korean-style crispy chicken burger', pr: 99, best: true, emoji: '🍔' },
  { id: 'b2', cat: 'Burger & Sandwich', veg: false, nm: 'The Crunch Boss Burger', ds: 'Loaded crunchy chicken burger', pr: 89, emoji: '🍔' },
  { id: 'b3', cat: 'Burger & Sandwich', veg: true, nm: 'Desi Aloo Tikki Burger', ds: 'Classic spiced aloo tikki burger', pr: 59, emoji: '🍔' },
  { id: 'b4', cat: 'Burger & Sandwich', veg: true, nm: 'The Garden Crunch Burger', ds: 'Fresh veggie crunch burger', pr: 69, emoji: '🍔' },
  { id: 'b5', cat: 'Burger & Sandwich', veg: false, nm: 'Chicken Tikka Sandwich', ds: 'Grilled chicken tikka sandwich', pr: 99, emoji: '🥪' },
  { id: 'b6', cat: 'Burger & Sandwich', veg: true, nm: 'Paneer Melt Sandwich', ds: 'Melted cheese & paneer sandwich', pr: 89, emoji: '🥪' },
  { id: 'b7', cat: 'Burger & Sandwich', veg: true, nm: 'Street-Style Spiced Aloo Toasty', ds: 'Toasted spiced potato sandwich', pr: 79, emoji: '🥪' },
  { id: 'b8', cat: 'Burger & Sandwich', veg: true, nm: 'Cheesy Veg Melt', ds: 'Loaded veg & cheese melt', pr: 69, emoji: '🥪' },

  // Beverages
  { id: 'd1', cat: 'Beverages', veg: true, nm: 'The Original Milk Boba', ds: 'Classic milk tea with boba pearls', pr: 99, emoji: '🧋' },
  { id: 'd2', cat: 'Beverages', veg: true, nm: 'Strawberry Boba Tea', ds: 'Strawberry-flavoured boba tea', pr: 99, emoji: '🧋' },
  { id: 'd3', cat: 'Beverages', veg: true, nm: 'Tropical Mango Burst Boba', ds: 'Mango boba tea', pr: 99, emoji: '🧋' },
  { id: 'd4', cat: 'Beverages', veg: true, nm: 'Zingo Classic Cold Coffee', ds: 'House cold coffee', pr: 79, emoji: '🥤' },
  { id: 'd5', cat: 'Beverages', veg: true, nm: 'Caramel Bliss Cold Coffee', ds: 'Cold coffee with caramel drizzle', pr: 89, emoji: '🥤' },
  { id: 'd6', cat: 'Beverages', veg: true, nm: 'Choco Blast Cold Coffee', ds: 'Chocolate loaded cold coffee', pr: 99, best: true, emoji: '🥤' },
  { id: 'd7', cat: 'Beverages', veg: true, nm: 'Velvet Taro Dream Boba', ds: 'Creamy taro boba tea', pr: 99, best: true, emoji: '🧋' },

  // Add-ons
  { id: 'x1', cat: 'Add-ons', veg: true, nm: 'Boba Pearls', ds: 'Extra topping', pr: 19, emoji: '⚫' },
  { id: 'x2', cat: 'Add-ons', veg: true, nm: 'Cheese Slice', ds: 'Extra topping', pr: 15, emoji: '🧀' },
  { id: 'x3', cat: 'Add-ons', veg: true, nm: 'Mozzarella Cheese', ds: 'Extra topping', pr: 29, emoji: '🧀' },
];

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

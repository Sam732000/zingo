import React, { useState } from 'react';
import {
  MapPin,
  Navigation,
  Check,
  Plus,
  Home,
  Briefcase,
  User,
  ArrowLeft,
  ArrowRight,
  Gift,
  Utensils,
  Bike,
  CheckCircle2,
  Loader2,
  Sparkles,
} from 'lucide-react';
import { GEOAPIFY_API_KEY } from '../data';
import { CustomerDetails, UserProfile } from '../types';

interface CheckoutViewProps {
  user?: UserProfile;
  onProceedToPayment: (details: CustomerDetails, lat: number | null, lng: number | null) => void;
  onNavigate: (step: any) => void;
}

interface SavedAddressItem {
  id: string;
  type: 'Home' | 'Work' | 'Other';
  icon: string;
  title: string;
  areaLocation: string;
  addressDetails: string;
  pin: string;
  city: string;
}

export const CheckoutView: React.FC<CheckoutViewProps> = ({
  user,
  onProceedToPayment,
  onNavigate,
}) => {
  // Pre-saved Zomato-style Addresses
  const savedAddresses: SavedAddressItem[] = [
    {
      id: 'addr-home',
      type: 'Home',
      icon: '🏠',
      title: 'Home',
      areaLocation: 'Barasat, Kolkata, West Bengal, India',
      addressDetails: 'Flat 1976/2, 2nd Floor, Green View Apartments, Noapara',
      pin: '700124',
      city: 'Barasat',
    },
    {
      id: 'addr-work',
      type: 'Work',
      icon: '💼',
      title: 'Work',
      areaLocation: 'Sector V, Salt Lake, Kolkata, West Bengal, India',
      addressDetails: 'Suite 4B, 4th Floor, Tech Park Tower 2, Sector V',
      pin: '700091',
      city: 'Kolkata',
    },
    {
      id: 'addr-other',
      type: 'Other',
      icon: '📍',
      title: 'Other',
      areaLocation: 'Jessore Road, Barasat, Kolkata, West Bengal, India',
      addressDetails: 'House No. 18, Lake View Enclave, near Star Club',
      pin: '700125',
      city: 'Barasat',
    },
  ];

  // Address State (initialize with empty strings so placeholders act as watermark guidance)
  const [selectedAddressId, setSelectedAddressId] = useState<string>('addr-home');
  const [areaLocation, setAreaLocation] = useState<string>('');
  const [addressDetails, setAddressDetails] = useState<string>('');
  const [city, setCity] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [isEditingAddress, setIsEditingAddress] = useState<boolean>(false);

  // Guest / User Details State
  const [guestName, setGuestName] = useState<string>('');
  const [guestPhone, setGuestPhone] = useState<string>('');

  // Ordering for someone else toggle
  const [isOrderingForOther, setIsOrderingForOther] = useState<boolean>(false);
  const [receiverName, setReceiverName] = useState<string>('');
  const [receiverPhone, setReceiverPhone] = useState<string>('');

  // Kitchen & Delivery Instructions State
  const [orderNotes, setOrderNotes] = useState<string>('');
  const [deliveryInstructions, setDeliveryInstructions] = useState<string>('');

  // Geolocation State
  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);
  const [loadingLoc, setLoadingLoc] = useState<boolean>(false);
  const [locSuccess, setLocSuccess] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const cookingPresets = [
    '🌶️ Make it Extra Spicy',
    '🍃 Less Oil & Mild Spice',
    '🧄 No Onion / No Garlic',
    '🍴 Include Cutlery & Napkins',
    '📦 Pack Extra Dips & Sauces',
  ];

  const deliveryPresets = [
    '🚪 Leave at doorstep',
    '🔔 Ring doorbell once',
    '📞 Call upon arrival',
    '🤫 Don\'t ring bell / Silent',
    '🛡️ Hand over to security guard',
  ];

  const togglePreset = (
    currentText: string,
    setText: (val: string) => void,
    preset: string
  ) => {
    if (currentText.includes(preset)) {
      const updated = currentText
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s && s !== preset)
        .join(', ');
      setText(updated);
    } else {
      const updated = currentText ? `${currentText.trim()}, ${preset}` : preset;
      setText(updated);
    }
  };

  const handleSelectSavedAddress = (addr: SavedAddressItem) => {
    if (selectedAddressId === addr.id) {
      setSelectedAddressId('');
    } else {
      setSelectedAddressId(addr.id);
    }
    // Keep input values empty so watermark placeholders are shown
    setAreaLocation('');
    setAddressDetails('');
    setCity('');
    setPin('');
    setIsEditingAddress(false);
  };

  const handleSelectNewAddress = () => {
    setSelectedAddressId('addr-new');
    setAreaLocation('');
    setAddressDetails('');
    setCity('');
    setPin('');
    setIsEditingAddress(true);
  };

  const handleUseLocation = () => {
    setErrorMsg(null);
    setLocSuccess(false);

    if (!navigator.geolocation) {
      setErrorMsg("Your browser doesn't support geolocation.");
      return;
    }

    setLoadingLoc(true);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setLat(latitude);
        setLng(longitude);

        try {
          const res = await fetch(
            `https://api.geoapify.com/v1/geocode/reverse?lat=${latitude}&lon=${longitude}&lang=en&format=json&apiKey=${GEOAPIFY_API_KEY}`
          );
          const data = await res.json();

          if (data && data.results && data.results.length > 0) {
            const p = data.results[0];
            const fullLoc = p.formatted || `${p.suburb || p.city || 'Barasat'}, ${p.city || 'Kolkata'}, West Bengal, India`;
            const line1 = p.address_line1 || [p.housenumber, p.street].filter(Boolean).join(' ') || p.suburb || '';
            const cty = p.city || p.town || 'Barasat';
            const postal = p.postcode || '700124';

            setAreaLocation(fullLoc);
            if (line1) setAddressDetails(line1);
            setCity(cty);
            setPin(postal);
            setLocSuccess(true);
          } else {
            setErrorMsg("Couldn't resolve location automatically. Please type details.");
          }
        } catch {
          setErrorMsg("Failed to reverse geocode location. Please enter manually.");
        } finally {
          setLoadingLoc(false);
        }
      },
      (error) => {
        setLoadingLoc(false);
        setErrorMsg(
          error.code === error.PERMISSION_DENIED
            ? 'Location permission denied. Please enter address manually.'
            : "Couldn't fetch location. Please enter address manually."
        );
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const isLoggedIn = Boolean(user && user.isLoggedIn);

    // Validate User / Guest Identity
    let finalName = '';
    let finalPhone = '';

    if (isLoggedIn) {
      finalName = user?.name || 'Valued Customer';
      finalPhone = user?.phone || '9876543210';
    } else {
      if (!guestName.trim()) {
        setErrorMsg('Please enter your full name.');
        return;
      }
      if (!/^\d{10}$/.test(guestPhone.trim())) {
        setErrorMsg('Please enter a valid 10-digit phone number.');
        return;
      }
      finalName = guestName.trim();
      finalPhone = guestPhone.trim();
    }

    // Validate Receiver details if ordering for someone else
    if (isOrderingForOther) {
      if (!receiverName.trim()) {
        setErrorMsg("Please enter the receiver's name.");
        return;
      }
      if (!/^\d{10}$/.test(receiverPhone.trim())) {
        setErrorMsg("Please enter a valid 10-digit phone number for the receiver.");
        return;
      }
    }

    // Resolve address details
    let finalAddressDetails = addressDetails.trim();
    let finalArea = areaLocation.trim();
    let finalCity = city.trim();
    let finalPin = pin.trim();

    const activeSaved = savedAddresses.find((a) => a.id === selectedAddressId);
    if (activeSaved) {
      if (!finalAddressDetails) finalAddressDetails = activeSaved.addressDetails;
      if (!finalArea) finalArea = activeSaved.areaLocation;
      if (!finalCity) finalCity = activeSaved.city;
      if (!finalPin) finalPin = activeSaved.pin;
    }

    if (!finalAddressDetails) {
      setErrorMsg('Please enter your specific address details (Floor, House no, Landmark).');
      return;
    }

    if (!finalArea) {
      finalArea = 'Barasat, Kolkata, West Bengal, India';
    }

    // Assemble Notes
    let combinedDeliveryInstructions = deliveryInstructions.trim();
    if (isOrderingForOther) {
      const receiverTag = `🎁 Deliver to receiver: ${receiverName.trim()} (${receiverPhone.trim()})`;
      combinedDeliveryInstructions = combinedDeliveryInstructions
        ? `${combinedDeliveryInstructions} | ${receiverTag}`
        : receiverTag;
    }

    onProceedToPayment(
      {
        name: finalName,
        phone: finalPhone,
        address: finalAddressDetails,
        area: finalArea,
        pin: finalPin || '700124',
        city: finalCity || 'Barasat',
        district: 'North 24 Parganas',
        state: 'West Bengal',
        orderNotes: orderNotes.trim(),
        deliveryInstructions: combinedDeliveryInstructions,
      },
      lat,
      lng
    );
  };

  const isLoggedIn = Boolean(user && user.isLoggedIn);

  return (
    <div className="max-w-xl mx-auto space-y-5 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-serif italic text-white">Delivery Details</h2>
          <p className="text-zinc-400 text-xs">Select address and complete your order</p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('cart')}
          className="text-xs text-zinc-400 hover:text-white font-mono transition-colors"
        >
          ← Back to Cart
        </button>
      </div>

      {/* 1. AUTHENTICATION STATE AWARENESS */}
      {isLoggedIn ? (
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
              👤
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">
                  Ordering as {user?.name || 'Valued Customer'}
                </span>
                <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-mono font-bold uppercase">
                  Logged In
                </span>
              </div>
              <span className="text-[11px] text-zinc-400 font-mono">+91 {user?.phone}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="text-xs text-amber-400/90 hover:text-amber-300 underline underline-offset-2 font-mono"
          >
            Switch Account
          </button>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-transparent border border-amber-500/30 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
          <div className="space-y-0.5">
            <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <span>🔑</span>
              <span>Already have an account?</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              Log in with your phone number for 1-tap saved address checkout.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="shrink-0 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs px-3.5 py-1.5 rounded-xl transition-all shadow-sm"
          >
            Login to Proceed
          </button>
        </div>
      )}

      {/* 2. ZOMATO-STYLE SAVED ADDRESSES (Compact & Minimal) */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-3 space-y-2">
        <div className="flex items-center justify-between text-[11px]">
          <span className="uppercase tracking-wider text-zinc-400 font-medium flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-amber-400" />
            <span>Saved Addresses</span>
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">Deliver to</span>
        </div>

        <div className="grid grid-cols-3 gap-1.5">
          {savedAddresses.map((addr) => {
            const isSelected = selectedAddressId === addr.id;
            const IconComponent =
              addr.type === 'Home' ? Home : addr.type === 'Work' ? Briefcase : MapPin;

            return (
              <button
                key={addr.id}
                type="button"
                onClick={() => handleSelectSavedAddress(addr)}
                className={`px-2.5 py-1.5 rounded-lg border text-left transition-all flex items-center justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-500/60 text-white'
                    : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  <IconComponent className="w-3.5 h-3.5 shrink-0 text-amber-400/90" />
                  <span className="text-xs font-medium truncate text-zinc-100">{addr.title}</span>
                </div>
                {isSelected && <Check className="w-3 h-3 text-amber-400 shrink-0 stroke-[3]" />}
              </button>
            );
          })}
        </div>

        <div>
          <button
            type="button"
            onClick={handleSelectNewAddress}
            className={`w-full py-1.5 px-2.5 rounded-lg border border-dashed text-[11px] font-medium flex items-center justify-center gap-1.5 transition-all ${
              selectedAddressId === 'addr-new'
                ? 'border-amber-500/60 bg-amber-500/10 text-amber-300 font-semibold'
                : 'border-zinc-800/80 text-zinc-400 hover:text-white hover:border-zinc-700'
            }`}
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Add New Address</span>
          </button>
        </div>

        {/* INLINE EXPANDABLE NEW ADDRESS FORM */}
        {selectedAddressId === 'addr-new' && (
          <div className="mt-2.5 p-3.5 bg-zinc-950/90 border border-amber-500/30 rounded-2xl space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
              <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                <span>New Address Details</span>
              </span>
              <button
                type="button"
                onClick={handleUseLocation}
                disabled={loadingLoc}
                className="bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 hover:border-amber-500/60 text-amber-300 hover:text-amber-200 px-2.5 py-1 rounded-lg text-[11px] font-medium flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-60"
              >
                {loadingLoc ? (
                  <Loader2 className="w-3 h-3 text-amber-400 animate-spin" />
                ) : locSuccess ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                ) : (
                  <Navigation className="w-3 h-3 text-amber-400" />
                )}
                <span>{loadingLoc ? 'Locating...' : 'Use current location'}</span>
              </button>
            </div>

            {/* Address Details Field */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                Address Details (House / Flat No, Floor, Landmark) *
              </label>
              <input
                type="text"
                value={addressDetails}
                onChange={(e) => setAddressDetails(e.target.value)}
                placeholder="e.g. Flat 4B, Emerald Enclave, Block A, Near Star Mall"
                className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/60 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                autoFocus
              />
            </div>

            {/* Location / Area Field */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                Location / Area *
              </label>
              <div className="relative flex items-center">
                <MapPin className="w-3.5 h-3.5 absolute left-3 text-amber-400" />
                <input
                  type="text"
                  value={areaLocation}
                  onChange={(e) => setAreaLocation(e.target.value)}
                  placeholder="e.g. Barasat, Kolkata, West Bengal, India"
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/60 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                />
              </div>
            </div>

            {/* City & Pin Code Grid */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                  City / Town
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Kolkata"
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/60 rounded-xl px-2.5 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                  Pin Code
                </label>
                <input
                  type="text"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="e.g. 700124"
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/60 rounded-xl px-2.5 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors font-mono"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ERROR MESSAGE DISPLAY */}
      {errorMsg && (
        <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono">
          {errorMsg}
        </div>
      )}

      {/* FORM SECTION */}
      <form onSubmit={handleSubmit} className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4 space-y-4">
        {/* Guest Input Fields (Only shown if NOT logged in) */}
        {!isLoggedIn && (
          <div className="space-y-3 pb-3 border-b border-zinc-800/80">
            <div className="text-[11px] uppercase tracking-wider text-amber-400/90 font-medium flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-amber-400" />
              <span>Guest Contact Information *</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="e.g. Aditi Sharma"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                  Phone Number (10 Digits) *
                </label>
                <input
                  type="tel"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* 3. STREAMLINED 2-TIER ADDRESS INPUT LAYOUT */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase tracking-wider text-amber-400/90 font-medium flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span>Delivery Destination *</span>
            </span>
            <button
              type="button"
              onClick={handleUseLocation}
              disabled={loadingLoc}
              className="bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 hover:border-amber-500/60 text-amber-300 hover:text-amber-200 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-60 group shadow-sm"
            >
              {loadingLoc ? (
                <Loader2 className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              ) : locSuccess ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Navigation className="w-3.5 h-3.5 text-amber-400 group-hover:rotate-45 transition-transform duration-300" />
              )}
              <span>{loadingLoc ? 'Locating...' : 'Use current location'}</span>
            </button>
          </div>

          {/* Field 1: Specific Address Details (Floor, House No, Landmark) */}
          <div className="space-y-1">
            <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
              Address Details *
            </label>
            <input
              type="text"
              value={addressDetails}
              onChange={(e) => setAddressDetails(e.target.value)}
              placeholder={
                savedAddresses.find((a) => a.id === selectedAddressId)
                  ? `e.g. ${savedAddresses.find((a) => a.id === selectedAddressId)?.addressDetails}`
                  : 'E.g. Floor, House no, Landmark'
              }
              className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/60 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
            />
          </div>

          {/* Field 2: General Area Location (Auto-detected or area string) */}
          <div className="space-y-1">
            <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
              Location / Area *
            </label>
            <div className="relative flex items-center">
              <MapPin className="w-3.5 h-3.5 absolute left-3 text-amber-400" />
              <input
                type="text"
                value={areaLocation}
                onChange={(e) => setAreaLocation(e.target.value)}
                placeholder={
                  savedAddresses.find((a) => a.id === selectedAddressId)
                    ? `e.g. ${savedAddresses.find((a) => a.id === selectedAddressId)?.areaLocation}`
                    : 'Barasat, Kolkata, West Bengal, India'
                }
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/60 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
              />
            </div>
          </div>
        </div>

        {/* 4. "ORDERING FOR SOMEONE ELSE?" TOGGLE */}
        <div className="pt-2 border-t border-zinc-800/80 space-y-2.5">
          <label className="flex items-center gap-2.5 cursor-pointer select-none group">
            <input
              type="checkbox"
              checked={isOrderingForOther}
              onChange={(e) => setIsOrderingForOther(e.target.checked)}
              className="w-4 h-4 rounded border-zinc-700 bg-zinc-950 text-amber-500 focus:ring-amber-500/40 cursor-pointer accent-amber-500"
            />
            <span className="text-xs font-medium text-zinc-300 group-hover:text-white transition-colors">
              Ordering for someone else?
            </span>
          </label>

          {isOrderingForOther && (
            <div className="bg-zinc-950/80 border border-zinc-800/90 p-3 rounded-xl space-y-2.5 animate-fadeIn">
              <div className="text-[11px] uppercase tracking-wider text-amber-400 font-medium flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5 text-amber-400" />
                <span>Receiver Details</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                    Receiver's Name *
                  </label>
                  <input
                    type="text"
                    value={receiverName}
                    onChange={(e) => setReceiverName(e.target.value)}
                    placeholder="e.g. Sam Majumdar"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500/50"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">
                    Receiver's Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={receiverPhone}
                    onChange={(e) => setReceiverPhone(e.target.value)}
                    placeholder="10-digit mobile number"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500/50 font-mono"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* INSTRUCTIONS SECTION (Single box with back-to-back quick toggles) */}
        <div className="pt-2 border-t border-zinc-800/80 space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[11px] uppercase tracking-wider text-amber-400/90 font-medium flex items-center gap-1.5">
              <Utensils className="w-3.5 h-3.5 text-amber-400" />
              <span>Kitchen & Rider Instructions</span>
            </label>
            <span className="text-[10px] text-zinc-500 font-mono">Optional</span>
          </div>

          <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl px-3.5 py-2.5 space-y-2.5 transition-colors">
            {/* 1. Quick Kitchen Instructions Toggle */}
            <details className="group text-xs text-zinc-400">
              <summary className="cursor-pointer select-none text-[11px] font-medium text-amber-400/90 hover:text-amber-300 transition-colors flex items-center justify-between py-1">
                <span className="flex items-center gap-1.5">
                  <Utensils className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate">
                    Add quick kitchen instructions
                    {orderNotes && (
                      <span className="ml-2 text-[10px] text-amber-300/80 font-normal">
                        ({orderNotes})
                      </span>
                    )}
                  </span>
                </span>
                <span className="text-[9px] text-zinc-500 group-open:rotate-180 transition-transform ml-2">▼</span>
              </summary>
              <div className="pt-2 pb-1 space-y-2 border-t border-zinc-800/40 mt-1">
                <input
                  type="text"
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="e.g. Extra spicy, less oil, non-veg separate..."
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                />
                <div className="flex flex-wrap gap-1.5">
                  {cookingPresets.map((preset) => {
                    const isActive = orderNotes.includes(preset);
                    return (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => togglePreset(orderNotes, setOrderNotes, preset)}
                        className={`text-[11px] px-2.5 py-1 rounded-full border transition-all ${
                          isActive
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-medium'
                            : 'bg-zinc-900/80 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                        }`}
                      >
                        {preset} {isActive ? '✓' : '+'}
                      </button>
                    );
                  })}
                </div>
              </div>
            </details>

            {/* 2. Quick Delivery Rider Instructions Toggle */}
            <details className="group text-xs text-zinc-400 border-t border-zinc-800/60 pt-2">
              <summary className="cursor-pointer select-none text-[11px] font-medium text-orange-400/90 hover:text-orange-300 transition-colors flex items-center justify-between py-1">
                <span className="flex items-center gap-1.5">
                  <Bike className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                  <span className="truncate">
                    Add quick delivery rider instructions
                    {deliveryInstructions && (
                      <span className="ml-2 text-[10px] text-orange-300/80 font-normal">
                        ({deliveryInstructions})
                      </span>
                    )}
                  </span>
                </span>
                <span className="text-[9px] text-zinc-500 group-open:rotate-180 transition-transform ml-2">▼</span>
              </summary>
              <div className="pt-2 pb-1 space-y-2 border-t border-zinc-800/40 mt-1">
                <input
                  type="text"
                  value={deliveryInstructions}
                  onChange={(e) => setDeliveryInstructions(e.target.value)}
                  placeholder="e.g. Ring doorbell once, leave with security..."
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-orange-500/50 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none transition-colors"
                />
                <div className="flex flex-wrap gap-1.5">
                  {deliveryPresets.map((preset) => {
                    const isActive = deliveryInstructions.includes(preset);
                    return (
                      <button
                        key={preset}
                        type="button"
                        onClick={() =>
                          togglePreset(deliveryInstructions, setDeliveryInstructions, preset)
                        }
                        className={`text-[11px] px-2.5 py-1 rounded-full border transition-all ${
                          isActive
                            ? 'bg-orange-500/20 text-orange-300 border-orange-500/40 font-medium'
                            : 'bg-zinc-900/80 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                        }`}
                      >
                        {preset} {isActive ? '✓' : '+'}
                      </button>
                    );
                  })}
                </div>
              </div>
            </details>
          </div>
        </div>

        {/* SUBMIT BUTTONS */}
        <div className="pt-3 flex gap-3">
          <button
            type="button"
            onClick={() => onNavigate('cart')}
            className="w-1/3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-3 px-4 rounded-xl text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
          <button
            type="submit"
            className="w-2/3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black font-extrabold py-3 px-4 rounded-xl text-xs uppercase tracking-wider transition-all shadow-md shadow-orange-500/20 flex items-center justify-center gap-1.5"
          >
            <span>Continue to Payment</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </form>
    </div>
  );
};

import React, { useState } from 'react';

interface PaymentViewProps {
  orderTotal: number;
  onConfirmOrder: (method: 'whatsapp' | 'phonepe' | 'razorpay') => Promise<void>;
  onNavigate: (step: any) => void;
}

export const PaymentView: React.FC<PaymentViewProps> = ({
  orderTotal,
  onConfirmOrder,
  onNavigate,
}) => {
  const [selectedMethod, setSelectedMethod] = useState<'whatsapp' | 'phonepe' | 'razorpay'>('whatsapp');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showWaConfirm, setShowWaConfirm] = useState(false);

  const handlePay = async () => {
    setIsProcessing(true);

    if (selectedMethod === 'whatsapp') {
      // Create order object and open WhatsApp
      await onConfirmOrder('whatsapp');
      setIsProcessing(false);
      setShowWaConfirm(true);
    } else {
      // Simulate gateway payment delay
      setTimeout(async () => {
        await onConfirmOrder(selectedMethod);
        setIsProcessing(false);
      }, 1500);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-3xl font-serif italic text-white">Payment Method</h2>
        <p className="text-zinc-400 text-sm">Choose your preferred way to pay.</p>
      </div>

      {!showWaConfirm ? (
        <div className="space-y-4">
          {/* Payment Options */}
          <div className="space-y-3">
            {/* WhatsApp Option */}
            <div
              onClick={() => setSelectedMethod('whatsapp')}
              className={`glass p-5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-4 ${
                selectedMethod === 'whatsapp'
                  ? 'border-emerald-500/80 bg-emerald-500/10 shadow-lg shadow-emerald-500/10'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold text-xl flex-shrink-0">
                  💬
                </div>
                <div>
                  <div className="font-bold text-white text-base flex items-center gap-2">
                    Order via WhatsApp
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-mono">
                      Recommended
                    </span>
                  </div>
                  <div className="text-zinc-400 text-xs mt-0.5">
                    Send order details on WhatsApp &amp; pay on delivery
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  selectedMethod === 'whatsapp'
                    ? 'border-emerald-400 bg-emerald-400'
                    : 'border-zinc-600'
                }`}
              >
                {selectedMethod === 'whatsapp' && <span className="w-2 h-2 rounded-full bg-black"></span>}
              </div>
            </div>

            {/* PhonePe Option (Coming Soon) */}
            <div
              onClick={() => setSelectedMethod('phonepe')}
              className={`glass p-5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-4 opacity-75 ${
                selectedMethod === 'phonepe'
                  ? 'border-purple-500/80 bg-purple-500/10'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-700 text-white font-black text-lg flex items-center justify-center flex-shrink-0">
                  Pe
                </div>
                <div>
                  <div className="font-bold text-white text-base flex items-center gap-2">
                    PhonePe
                    <span className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded-full font-mono">
                      Demo Mode
                    </span>
                  </div>
                  <div className="text-zinc-400 text-xs mt-0.5">UPI, Cards, Wallets &amp; Netbanking</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  selectedMethod === 'phonepe' ? 'border-purple-400 bg-purple-400' : 'border-zinc-600'
                }`}
              >
                {selectedMethod === 'phonepe' && <span className="w-2 h-2 rounded-full bg-black"></span>}
              </div>
            </div>

            {/* Razorpay Option (Coming Soon) */}
            <div
              onClick={() => setSelectedMethod('razorpay')}
              className={`glass p-5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-4 opacity-75 ${
                selectedMethod === 'razorpay'
                  ? 'border-blue-500/80 bg-blue-500/10'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-900 text-blue-400 font-black text-lg flex items-center justify-center flex-shrink-0">
                  RP
                </div>
                <div>
                  <div className="font-bold text-white text-base flex items-center gap-2">
                    Razorpay
                    <span className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded-full font-mono">
                      Demo Mode
                    </span>
                  </div>
                  <div className="text-zinc-400 text-xs mt-0.5">UPI, Debit/Credit Cards &amp; Netbanking</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  selectedMethod === 'razorpay' ? 'border-blue-400 bg-blue-400' : 'border-zinc-600'
                }`}
              >
                {selectedMethod === 'razorpay' && <span className="w-2 h-2 rounded-full bg-black"></span>}
              </div>
            </div>
          </div>

          {/* Amount Box */}
          <div className="glass p-5 rounded-2xl flex items-center justify-between border-orange-500/20">
            <span className="text-zinc-400 text-sm font-mono">Amount Payable</span>
            <span className="text-orange-400 font-serif italic text-2xl font-bold">₹{orderTotal}</span>
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => onNavigate('checkout')}
              className="w-1/3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-4 rounded-full text-xs uppercase tracking-wider transition-all"
            >
              Back
            </button>

            <button
              onClick={handlePay}
              disabled={isProcessing}
              className="w-2/3 bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 rounded-full text-xs uppercase tracking-widest transition-all shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <span>⏳ Processing Order...</span>
              ) : selectedMethod === 'whatsapp' ? (
                <span>Send Order on WhatsApp &rarr;</span>
              ) : (
                <span>Pay ₹{orderTotal} Now &rarr;</span>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* WhatsApp Modal / Waiting View */
        <div className="glass p-8 rounded-3xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center text-3xl mx-auto shadow-lg shadow-emerald-500/20">
            💬
          </div>
          <div>
            <h3 className="text-2xl font-serif italic text-white mb-2">WhatsApp Opened</h3>
            <p className="text-zinc-400 text-sm max-w-sm mx-auto">
              Send the pre-filled message on WhatsApp to confirm your order with our kitchen team.
            </p>
          </div>

          <div className="pt-2 space-y-3">
            <button
              onClick={() => onNavigate('confirm')}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-4 rounded-full text-xs uppercase tracking-widest transition-all shadow-lg shadow-emerald-500/20"
            >
              I've Sent the Message on WhatsApp
            </button>

            <button
              onClick={() => setShowWaConfirm(false)}
              className="text-xs text-zinc-500 hover:text-zinc-300 underline uppercase tracking-wider"
            >
              Go Back
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

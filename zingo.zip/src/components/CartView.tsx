import React from 'react';
import { motion } from 'motion/react';
import { MENU, PACKAGING_FEE, MIN_CART_FOR_FREE_DELIVERY } from '../data';

interface CartViewProps {
  cart: Record<string, number>;
  onAddItem: (id: string) => void;
  onDecItem: (id: string) => void;
  onNavigate: (step: any) => void;
  deliveryFee: number;
  distanceKm: number | null;
}

const VegNonVegIcon: React.FC<{ isVeg: boolean; className?: string }> = ({ isVeg, className = '' }) => (
  <div
    className={`w-3.5 h-3.5 border flex items-center justify-center bg-zinc-950/95 rounded-[3px] p-[1px] ${
      isVeg ? 'border-emerald-500' : 'border-red-500'
    } ${className}`}
    title={isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
  >
    <div
      className={`w-1.5 h-1.5 rounded-full ${
        isVeg ? 'bg-emerald-500' : 'bg-red-500'
      }`}
    />
  </div>
);

export const CartView: React.FC<CartViewProps> = ({
  cart,
  onAddItem,
  onDecItem,
  onNavigate,
  deliveryFee,
  distanceKm,
}) => {
  const cartItemIds = Object.keys(cart);
  const subtotal = cartItemIds.reduce((sum, id) => {
    const item = MENU.find((m) => m.id === id);
    return sum + (item ? item.pr * (cart[id] || 0) : 0);
  }, 0);

  const total = subtotal + deliveryFee + PACKAGING_FEE;
  const addons = MENU.filter((i) => i.cat === 'Add-ons' || i.cat === 'Beverages');

  if (cartItemIds.length === 0) {
    return (
      <div className="glass p-12 rounded-3xl text-center space-y-6 max-w-lg mx-auto my-12 animate-fadeIn">
        <div className="text-6xl">🍱</div>
        <div>
          <h2 className="text-2xl font-serif italic text-white mb-2">Your cart is empty</h2>
          <p className="text-zinc-400 text-sm">Add some delicious items from our menu to get started.</p>
        </div>
        <button
          onClick={() => onNavigate('menu')}
          className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-8 py-3 rounded-full text-xs uppercase tracking-widest transition-all"
        >
          Browse Menu
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-serif italic text-white">Your Cart</h2>
          <p className="text-zinc-400 text-sm">Review your order before proceeding to details.</p>
        </div>
        <button
          onClick={() => onNavigate('menu')}
          className="text-xs uppercase tracking-wider text-orange-400 hover:underline"
        >
          + Add More Items
        </button>
      </div>

      {/* Cart Items List */}
      <div className="space-y-3">
        {cartItemIds.map((id) => {
          const item = MENU.find((m) => m.id === id);
          if (!item) return null;
          const qty = cart[id];

          return (
            <div
              key={id}
              className="glass-card p-4 rounded-2xl flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3 flex-grow min-w-0">
                <span className="text-xl">{item.emoji || '🍕'}</span>
                <div className="min-w-0">
                  <div className="font-bold text-white text-xs sm:text-sm leading-tight break-words">{item.nm}</div>
                  <div className="text-zinc-500 text-xs font-mono">₹{item.pr} each</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 text-white rounded-full px-2 py-1">
                  <button
                    onClick={() => onDecItem(id)}
                    className="w-6 h-6 rounded-full hover:bg-zinc-800 flex items-center justify-center font-bold text-sm text-orange-400"
                  >
                    -
                  </button>
                  <span className="font-bold text-xs px-1">{qty}</span>
                  <button
                    onClick={() => onAddItem(id)}
                    className="w-6 h-6 rounded-full hover:bg-zinc-800 flex items-center justify-center font-bold text-sm text-orange-400"
                  >
                    +
                  </button>
                </div>

                <div className="font-serif italic text-orange-400 text-base font-bold min-w-[60px] text-right">
                  ₹{item.pr * qty}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recommended Add-ons / Complete Your Meal */}
      {addons.length > 0 && (
        <div className="space-y-2.5 pt-1">
          <div className="flex items-center justify-between">
            <div className="text-[11px] uppercase tracking-[0.18em] text-zinc-400 font-bold flex items-center gap-1.5">
              <span>✨</span>
              <span>Add Extras &amp; Toppings</span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono flex items-center gap-1">
              <span>Swipe</span>
              <span className="text-amber-400">↔</span>
            </span>
          </div>

          {/* Horizontal Scroll Row with Square Cards */}
          <div className="flex gap-2 overflow-x-auto pb-2 pt-1 scrollbar-none snap-x touch-pan-x -mx-1 px-1">
            {addons.map((addon) => {
              const qty = cart[addon.id] || 0;
              return (
                <div
                  key={addon.id}
                  className="w-[82px] sm:w-[90px] flex-shrink-0 snap-start flex flex-col group"
                >
                  {/* Square Photo/Emoji Box */}
                  <div className="relative aspect-square w-full bg-zinc-900/90 border border-zinc-800/90 group-hover:border-amber-500/40 rounded-lg flex items-center justify-center p-1.5 shadow-inner transition-all overflow-hidden">
                    {/* Veg / Non-Veg badge top-left */}
                    <VegNonVegIcon
                      isVeg={Boolean(addon.veg)}
                      className="absolute top-1 left-1 z-10 scale-75 shadow-md shadow-black/80"
                    />

                    {/* Emoji Photo */}
                    <span className="text-2xl select-none group-hover:scale-110 transition-transform duration-200">
                      {addon.emoji || (addon.veg ? '🥦' : '🍗')}
                    </span>

                    {/* Compact Zomato-style overlay add button on bottom-right corner */}
                    {qty === 0 ? (
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        onClick={() => onAddItem(addon.id)}
                        className="absolute bottom-1 right-1 z-10 bg-orange-500 hover:bg-orange-600 text-white rounded px-1.5 py-0.5 flex items-center gap-0.5 shadow-md shadow-black/60 font-black text-[9px] tracking-wider uppercase transition-transform"
                        title="Add item"
                      >
                        <span>+</span>
                        <span>ADD</span>
                      </motion.button>
                    ) : (
                      <div className="absolute bottom-1 right-1 z-10 flex items-center gap-0.5 bg-orange-500 text-white rounded px-1 py-0.5 shadow-md shadow-black/60 text-[9px] font-bold">
                        <button
                          onClick={() => onDecItem(addon.id)}
                          className="w-3.5 h-3.5 rounded bg-black/20 hover:bg-black/40 flex items-center justify-center text-[9px]"
                        >
                          -
                        </button>
                        <span className="px-0.5 font-mono text-[10px]">{qty}</span>
                        <button
                          onClick={() => onAddItem(addon.id)}
                          className="w-3.5 h-3.5 rounded bg-black/20 hover:bg-black/40 flex items-center justify-center text-[9px]"
                        >
                          +
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Details below square photo */}
                  <div className="mt-1 px-0.5 min-w-0">
                    <div
                      className="font-bold text-[11px] text-white truncate leading-tight group-hover:text-amber-400 transition-colors"
                      title={addon.nm}
                    >
                      {addon.nm}
                    </div>
                    <div className="font-serif italic text-[11px] text-amber-400 font-bold mt-0.5">
                      ₹{addon.pr}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bill Breakdown */}
      <div className="bg-zinc-900/90 border border-zinc-800 p-5 rounded-2xl space-y-3.5">
        <div className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium border-b border-zinc-800/80 pb-2.5 flex justify-between items-center">
          <span>Bill Summary</span>
          <span className="text-[10px] text-zinc-500 font-mono">Detailed</span>
        </div>

        <div className="space-y-2 text-xs font-mono">
          <div className="flex justify-between text-zinc-400">
            <span>Item Subtotal</span>
            <span>₹{subtotal}</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Delivery Fee</span>
            <span className={deliveryFee === 0 ? 'text-emerald-400 font-medium' : ''}>
              {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
            </span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Packaging &amp; Handling</span>
            <span>₹{PACKAGING_FEE}</span>
          </div>

          {/* Minimalist "To Pay" Card */}
          <div className="mt-3 p-3.5 rounded-xl bg-zinc-950/80 border border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="text-lg">💳</span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs uppercase tracking-wider text-zinc-200 font-medium">
                    To Pay
                  </span>
                  <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[9px] font-mono px-1.5 py-0.5 rounded uppercase">
                    Final
                  </span>
                </div>
                <span className="text-[10px] text-zinc-500 font-sans block mt-0.5">
                  Inclusive of all items &amp; taxes
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="block font-serif italic font-bold text-2xl text-amber-400">
                ₹{total}
              </span>
            </div>
          </div>
        </div>

        {/* Minimalist Free Delivery Progress Card */}
        {(() => {
          const neededAmount = Math.max(0, MIN_CART_FOR_FREE_DELIVERY - subtotal);
          const progressPercent = Math.min(100, Math.round((subtotal / MIN_CART_FOR_FREE_DELIVERY) * 100));

          return (
            <div className="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3.5 space-y-2.5">
              {/* Header */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 font-medium text-zinc-300">
                  <span>🛵</span>
                  <span>Free Delivery Progress</span>
                </div>
                <span className="text-[10px] font-mono font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
                  {progressPercent}%
                </span>
              </div>

              {/* Thin Progress Bar */}
              <div className="w-full bg-zinc-900 rounded-full h-1.5 overflow-hidden border border-zinc-800/80">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 to-emerald-400"
                />
              </div>

              {/* Status Text */}
              <div className="text-xs font-sans leading-relaxed">
                {subtotal >= MIN_CART_FOR_FREE_DELIVERY ? (
                  <div className="flex items-center gap-2 text-emerald-400 font-medium bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-lg text-xs">
                    <span>🎉</span>
                    <span>
                      <strong className="font-semibold text-emerald-300">FREE DELIVERY UNLOCKED!</strong> You saved on delivery charges.
                    </span>
                  </div>
                ) : (
                  <div className="text-zinc-300 bg-zinc-900/60 border border-zinc-800/80 p-2.5 rounded-lg space-y-1">
                    <div className="flex flex-wrap items-center gap-1.5 text-xs">
                      <span>Add</span>
                      
                      {/* Highlighted Remaining Amount */}
                      <span className="font-mono font-medium text-amber-300 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded text-xs">
                        ₹{neededAmount} more
                      </span>
                      
                      <span>for</span>

                      {/* Highlighted FREE DELIVERY Badge */}
                      <span className="font-mono font-medium text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded uppercase text-[10px] tracking-wider">
                        FREE DELIVERY
                      </span>

                      <span>within</span>

                      <span className="font-medium text-zinc-200 underline underline-offset-2 decoration-amber-500/50">
                        3 kilometers
                      </span>.
                    </div>

                    {distanceKm !== null && (
                      <div className="text-[10px] text-zinc-500 pt-0.5">
                        📍 Distance: {distanceKm.toFixed(1)} km {distanceKm > 3 ? '(beyond 3 km free zone)' : ''}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })()}

        <button
          onClick={() => onNavigate('checkout')}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 rounded-full text-xs uppercase tracking-widest transition-all shadow-lg shadow-orange-500/20"
        >
          Proceed to Details &rarr;
        </button>
      </div>
    </div>
  );
};

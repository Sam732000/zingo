import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { CartItem, Order } from '../types';

interface ConfirmViewProps {
  order: Order | null;
  orderHistory: Order[];
  onNewOrder: () => void;
  onSelectOrder: (order: Order) => void;
  onReorder: (items: CartItem[]) => void;
  onClearHistory: () => void;
  onSaveFeedback: (orderId: string, rating: number, comment: string) => void;
}

interface OrderFeedbackProps {
  order: Order;
  onSaveFeedback: (orderId: string, rating: number, comment: string) => void;
}

const OrderFeedbackCard: React.FC<OrderFeedbackProps> = ({ order, onSaveFeedback }) => {
  const existingFeedback = order.feedback;
  const [rating, setRating] = useState<number>(existingFeedback?.rating || 0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState<string>(existingFeedback?.comment || '');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(Boolean(existingFeedback));
  const [isEditing, setIsEditing] = useState<boolean>(!existingFeedback);

  useEffect(() => {
    setRating(order.feedback?.rating || 0);
    setComment(order.feedback?.comment || '');
    setIsSubmitted(Boolean(order.feedback));
    setIsEditing(!order.feedback);
  }, [order.id, order.feedback]);

  const ratingLabels: Record<number, { text: string; emoji: string }> = {
    1: { text: 'Poor', emoji: '😞' },
    2: { text: 'Fair', emoji: '😐' },
    3: { text: 'Good', emoji: '🙂' },
    4: { text: 'Very Good', emoji: '😊' },
    5: { text: 'Outstanding!', emoji: '🤩' },
  };

  const activeRating = hoverRating || rating;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating < 1) return;
    onSaveFeedback(order.id, rating, comment);
    setIsSubmitted(true);
    setIsEditing(false);
  };

  return (
    <div className="glass p-6 sm:p-7 rounded-3xl space-y-5 border border-amber-500/20 shadow-2xl relative overflow-hidden">
      {/* Background Subtle Glow Accent */}
      <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center text-lg">
            ⭐
          </div>
          <div>
            <h3 className="text-base font-serif italic text-white font-bold">Order Feedback</h3>
            <p className="text-[11px] text-zinc-400">Rate your food & service for #{order.id}</p>
          </div>
        </div>

        {isSubmitted && !isEditing && (
          <button
            onClick={() => setIsEditing(true)}
            className="text-[11px] font-mono text-amber-400 hover:text-amber-300 underline underline-offset-2 transition-colors"
          >
            Edit Feedback
          </button>
        )}
      </div>

      {isSubmitted && !isEditing ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-zinc-900/80 border border-amber-500/30 p-4 rounded-2xl space-y-2.5"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className={`text-xl ${
                    star <= (order.feedback?.rating || rating) ? 'text-amber-400' : 'text-zinc-700'
                  }`}
                >
                  ★
                </span>
              ))}
              <span className="ml-2 text-xs font-bold font-mono text-amber-400">
                {order.feedback?.rating || rating}/5 ({ratingLabels[order.feedback?.rating || rating]?.text})
              </span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">
              ✓ Saved locally
            </span>
          </div>

          {(order.feedback?.comment || comment) ? (
            <p className="text-xs text-zinc-300 bg-zinc-950/60 p-3 rounded-xl border border-zinc-800/80 italic font-sans leading-relaxed">
              "{order.feedback?.comment || comment}"
            </p>
          ) : (
            <p className="text-[11px] text-zinc-500 italic">No additional comment provided.</p>
          )}
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Star Selection */}
          <div className="space-y-2">
            <label className="text-xs text-zinc-300 font-mono font-medium block">
              How was your meal? <span className="text-orange-400">*</span>
            </label>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="p-1 transition-transform transform hover:scale-125 focus:outline-none"
                    aria-label={`Rate ${star} stars`}
                  >
                    <motion.span
                      animate={{ scale: activeRating >= star ? 1.1 : 1 }}
                      className={`text-2xl sm:text-3xl transition-colors cursor-pointer select-none ${
                        star <= activeRating
                          ? 'text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)]'
                          : 'text-zinc-700'
                      }`}
                    >
                      ★
                    </motion.span>
                  </button>
                ))}
              </div>

              {activeRating > 0 && (
                <motion.div
                  initial={{ opacity: 0, x: -5 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-xs font-bold text-amber-400 font-mono flex items-center gap-1 ml-2 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20"
                >
                  <span>{ratingLabels[activeRating]?.emoji}</span>
                  <span>{ratingLabels[activeRating]?.text}</span>
                </motion.div>
              )}
            </div>
          </div>

          {/* Comment Textarea */}
          <div className="space-y-1.5">
            <label className="text-xs text-zinc-300 font-mono font-medium flex items-center justify-between">
              <span>Short Comment / Note (Optional)</span>
              <span className="text-[10px] text-zinc-500">Max 250 chars</span>
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value.slice(0, 250))}
              placeholder="Tell us how the food tasted, delivery speed, or packaging..."
              rows={2}
              className="w-full bg-zinc-900/90 text-zinc-100 placeholder-zinc-500 text-xs p-3 rounded-2xl border border-zinc-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-all resize-none shadow-inner"
            />
          </div>

          {/* Submit Action Buttons */}
          <div className="flex items-center gap-3 pt-1">
            <button
              type="submit"
              disabled={rating === 0}
              className={`flex-grow py-3 rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 ${
                rating > 0
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-black shadow-amber-500/20 cursor-pointer'
                  : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
              }`}
            >
              <span>⭐</span>
              <span>{existingFeedback ? 'Update Feedback' : 'Save Feedback'}</span>
            </button>

            {existingFeedback && isEditing && (
              <button
                type="button"
                onClick={() => {
                  setIsEditing(false);
                  setIsSubmitted(true);
                }}
                className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-4 py-3 rounded-full text-xs font-mono font-bold transition-colors"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
};

export const ConfirmView: React.FC<ConfirmViewProps> = ({
  order,
  orderHistory,
  onNewOrder,
  onSelectOrder,
  onReorder,
  onClearHistory,
  onSaveFeedback,
}) => {
  const stages = [
    { key: 'placed', label: 'Order Placed', shortLabel: 'Placed', icon: '📝', time: 'Just now' },
    { key: 'preparing', label: 'Preparing in Kitchen', shortLabel: 'Preparing', icon: '👨‍🍳', time: '~10 mins' },
    { key: 'out', label: 'Out for Delivery', shortLabel: 'On the Way', icon: '🛵', time: '~25 mins' },
    { key: 'delivered', label: 'Delivered', shortLabel: 'Delivered', icon: '🎉', time: '~35 mins' },
  ];

  const statusMap: Record<string, number> = {
    placed: 0,
    preparing: 1,
    out: 2,
    delivered: 3,
  };

  const [currentStageIndex, setCurrentStageIndex] = useState(() => {
    return order ? statusMap[order.status] ?? 0 : 0;
  });

  useEffect(() => {
    if (!order) return;
    const initialIndex = statusMap[order.status] ?? 0;
    setCurrentStageIndex(initialIndex);

    // Auto advance order status in demo mode if order is active
    if (initialIndex < 3) {
      const t1 = setTimeout(() => setCurrentStageIndex((prev) => Math.max(prev, 1)), 5000);
      const t2 = setTimeout(() => setCurrentStageIndex((prev) => Math.max(prev, 2)), 15000);
      const t3 = setTimeout(() => setCurrentStageIndex((prev) => Math.max(prev, 3)), 28000);

      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(t3);
      };
    }
  }, [order?.id, order?.status]);

  const activeStageKey = stages[currentStageIndex]?.key || 'placed';

  const formatDate = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoStr;
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-fadeIn">
      {/* Active Selected Order Receipt & Tracker */}
      {order ? (
        <div className="space-y-6">
          {/* Paper Receipt Ticket */}
          <div className="bg-[#ede6d6] text-[#1b1b18] p-6 sm:p-8 rounded-2xl shadow-2xl relative overflow-hidden font-mono space-y-6">
            {/* Receipt Header */}
            <div className="text-center space-y-2 border-b border-[#b7ae94] pb-6">
              <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center text-2xl mx-auto mb-2 shadow-md">
                ✓
              </div>
              <h2 className="text-xl font-black uppercase tracking-wider font-sans">ORDER CONFIRMED</h2>
              <div className="text-xs text-[#6b6552] font-bold">Ticket ID: #{order.id}</div>
              <div className="text-[10px] text-[#8a8474]">Zingo • Taste can't wait • Barasat</div>
            </div>

            {/* Customer Info */}
            <div className="text-xs space-y-1 text-[#4a4636]">
              <div className="flex justify-between">
                <span className="text-[#8a8474]">Name:</span>
                <span className="font-bold text-[#1b1b18]">{order.customer.name || 'Valued Guest'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8a8474]">Phone:</span>
                <span className="font-bold text-[#1b1b18]">{order.customer.phone || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8a8474]">Delivery to:</span>
                <span className="font-bold text-[#1b1b18] text-right max-w-[200px] truncate">
                  {order.customer.area || order.customer.address}, {order.customer.pin}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8a8474]">Paid Via:</span>
                <span className="font-bold text-[#1b1b18] uppercase">{order.method}</span>
              </div>
              {(order.orderNotes || order.customer.orderNotes) && (
                <div className="pt-1.5 border-t border-dashed border-[#b7ae94]">
                  <span className="text-[#8a8474] block font-bold text-[11px] uppercase tracking-wider">
                    📝 Cooking Notes:
                  </span>
                  <p className="text-[#1b1b18] font-medium text-xs bg-[#f4ebd0] p-1.5 rounded mt-0.5 italic">
                    "{order.orderNotes || order.customer.orderNotes}"
                  </p>
                </div>
              )}
              {(order.deliveryInstructions || order.customer.deliveryInstructions) && (
                <div className="pt-1">
                  <span className="text-[#8a8474] block font-bold text-[11px] uppercase tracking-wider">
                    🛵 Delivery Instructions:
                  </span>
                  <p className="text-[#1b1b18] font-medium text-xs bg-[#f4ebd0] p-1.5 rounded mt-0.5 italic">
                    "{order.deliveryInstructions || order.customer.deliveryInstructions}"
                  </p>
                </div>
              )}
            </div>

            {/* Order Items List */}
            <div className="border-t border-b border-dashed border-[#b7ae94] py-4 space-y-2 text-xs">
              {order.items.map(({ item, qty }) => (
                <div key={item.id} className="flex justify-between">
                  <span>
                    {item.nm} × {qty}
                  </span>
                  <span className="font-bold">₹{item.pr * qty}</span>
                </div>
              ))}
            </div>

            {/* Bill Breakdown */}
            <div className="text-xs space-y-1 text-[#4a4636]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{order.subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>{order.deliveryFee === 0 ? 'FREE' : `₹${order.deliveryFee}`}</span>
              </div>
              <div className="flex justify-between">
                <span>Packaging</span>
                <span>₹{order.packagingFee}</span>
              </div>
              <div className="flex justify-between text-base font-black text-[#1b1b18] pt-2 border-t border-[#b7ae94] font-sans">
                <span>TOTAL</span>
                <span className="text-orange-600">₹{order.total}</span>
              </div>
            </div>
          </div>

          {/* Live Order Tracker & Visual Progress Bar */}
          <div className="glass p-6 rounded-3xl space-y-6 border border-orange-500/20 shadow-xl">
            <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">🛵</span>
                <h3 className="text-lg font-serif italic text-white">Live Order Tracker</h3>
              </div>
              <span className="text-xs font-mono text-orange-400 font-bold animate-pulse bg-orange-500/10 px-2.5 py-1 rounded-full border border-orange-500/20">
                ⏱️ ETA: {currentStageIndex === 3 ? 'Delivered 🎉' : '~35 mins'}
              </span>
            </div>

            {/* Visual Progress Bar Component */}
            <div className="space-y-4 pt-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-400 font-mono text-[11px]">Current Status:</span>
                <span
                  className={`font-bold px-3 py-1 rounded-full text-xs uppercase tracking-wider font-mono ${
                    activeStageKey === 'delivered'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : activeStageKey === 'out'
                      ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      : activeStageKey === 'preparing'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                  }`}
                >
                  {stages[currentStageIndex]?.label}
                </span>
              </div>

              {/* Horizontal Progress Bar Track */}
              <div className="relative pt-2 pb-6">
                <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden border border-zinc-700/50">
                  <motion.div
                    className="h-full bg-gradient-to-r from-orange-500 via-amber-500 to-emerald-500 shadow-sm shadow-orange-500/50"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentStageIndex + 1) / stages.length) * 100}%` }}
                    transition={{ duration: 0.6, ease: 'easeOut' }}
                  />
                </div>

                {/* Milestone Nodes */}
                <div className="flex justify-between -mt-4 relative z-10">
                  {stages.map((st, idx) => {
                    const isCompleted = idx < currentStageIndex;
                    const isCurrent = idx === currentStageIndex;

                    return (
                      <div key={st.key} className="flex flex-col items-center gap-1.5">
                        <motion.div
                          animate={{ scale: isCurrent ? 1.15 : 1 }}
                          transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                          className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                            isCurrent
                              ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/50 ring-4 ring-orange-500/20'
                              : isCompleted
                              ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                              : 'bg-zinc-800 text-zinc-500 border border-zinc-700'
                          }`}
                        >
                          {isCompleted ? '✓' : st.icon}
                        </motion.div>
                        <span
                          className={`text-[10px] sm:text-[11px] font-mono text-center max-w-[60px] sm:max-w-[75px] ${
                            isCurrent
                              ? 'text-orange-400 font-bold'
                              : isCompleted
                              ? 'text-zinc-300'
                              : 'text-zinc-500'
                          }`}
                        >
                          {st.shortLabel}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Vertical Detailed Steps */}
            <div className="space-y-3 pt-2 border-t border-zinc-800/80">
              {stages.map((stage, idx) => {
                const isDone = idx < currentStageIndex;
                const isActive = idx === currentStageIndex;

                return (
                  <div key={stage.key} className="flex items-center gap-3.5">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-orange-500 text-white shadow-md shadow-orange-500/30'
                          : isDone
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-zinc-800/80 text-zinc-600'
                      }`}
                    >
                      {isDone ? '✓' : idx + 1}
                    </div>

                    <div className="flex-grow flex items-center justify-between">
                      <div
                        className={`text-xs sm:text-sm font-bold ${
                          isActive ? 'text-orange-400' : isDone ? 'text-zinc-200' : 'text-zinc-500'
                        }`}
                      >
                        {stage.label}
                      </div>
                      <div className="text-[10px] text-zinc-500 font-mono">{stage.time}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Order Feedback Component */}
          <OrderFeedbackCard order={order} onSaveFeedback={onSaveFeedback} />

          <button
            onClick={onNewOrder}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 rounded-full text-xs uppercase tracking-widest transition-all shadow-lg shadow-orange-500/20"
          >
            + Place Another Order
          </button>
        </div>
      ) : (
        <div className="glass p-8 rounded-3xl text-center space-y-4 border border-zinc-800">
          <div className="text-4xl">📜</div>
          <h2 className="text-xl font-bold text-white">No Active Order Selected</h2>
          <p className="text-zinc-400 text-xs max-w-sm mx-auto">
            Browse your saved order history below or head to the menu to place a new order.
          </p>
          <button
            onClick={onNewOrder}
            className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-6 py-2.5 rounded-full text-xs uppercase tracking-widest transition-all"
          >
            Explore Menu
          </button>
        </div>
      )}

      {/* Persistent Local Storage Order History Section */}
      <div className="glass p-6 sm:p-8 rounded-3xl space-y-6 border border-zinc-800/80 shadow-2xl">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center text-xl">
              📜
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Order History
                <span className="text-[10px] bg-zinc-800 text-zinc-400 font-mono px-2 py-0.5 rounded-full font-normal">
                  Saved locally
                </span>
              </h3>
              <p className="text-zinc-400 text-xs">Your past food orders from Zingo Barasat</p>
            </div>
          </div>

          {orderHistory.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to clear your local order history?')) {
                  onClearHistory();
                }
              }}
              className="text-[11px] text-zinc-500 hover:text-red-400 font-mono transition-colors"
              title="Clear all saved orders"
            >
              Clear History
            </button>
          )}
        </div>

        {orderHistory.length === 0 ? (
          <div className="text-center py-8 space-y-2">
            <p className="text-zinc-400 text-sm">No previous orders found in local storage.</p>
            <p className="text-zinc-600 text-xs">When you place orders, they will appear here automatically!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orderHistory.map((pastOrder) => {
              const isCurrentView = order?.id === pastOrder.id;
              const pastStatus = pastOrder.status || 'placed';
              const activeStageIdx = isCurrentView ? currentStageIndex : (statusMap[pastStatus] ?? 3);
              const stagePercentages = [25, 50, 75, 100];
              const progressPercent = stagePercentages[activeStageIdx] ?? 100;
              const currentStageObj = stages[activeStageIdx] || stages[3];

              const stageColors = [
                'from-orange-500 to-amber-500',
                'from-amber-500 to-orange-400',
                'from-orange-500 to-emerald-400',
                'from-emerald-500 to-teal-400',
              ];
              const progressColor = stageColors[activeStageIdx] || stageColors[3];

              return (
                <div
                  key={pastOrder.id}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                    isCurrentView
                      ? 'border-orange-500/60 bg-orange-500/10 shadow-lg shadow-orange-500/5'
                      : 'border-zinc-800/80 bg-zinc-900/60 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800/60">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-orange-400 text-sm">
                          #{pastOrder.id}
                        </span>
                        {isCurrentView && (
                          <span className="text-[9px] bg-orange-500 text-white font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                            Viewing
                          </span>
                        )}
                        <span className="text-[10px] bg-zinc-800 text-zinc-300 font-mono px-2 py-0.5 rounded-full uppercase">
                          {pastOrder.method}
                        </span>
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono px-2 py-0.5 rounded-full uppercase">
                          {currentStageObj.shortLabel}
                        </span>
                      </div>
                      <div className="text-zinc-500 text-[11px] font-mono mt-0.5">
                        {formatDate(pastOrder.createdAt)}
                      </div>
                    </div>

                    <div className="text-right sm:text-right flex sm:flex-col justify-between items-center sm:items-end">
                      <span className="text-zinc-400 text-xs sm:hidden">Total:</span>
                      <span className="font-serif italic text-white font-bold text-lg">
                        ₹{pastOrder.total}
                      </span>
                    </div>
                  </div>

                  {/* Dynamic Status Progress Bar */}
                  <div className="pt-3 pb-1 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-zinc-300 font-bold flex items-center gap-1.5">
                        <span>{currentStageObj.icon}</span>
                        <span>{currentStageObj.label}</span>
                      </span>
                      <span className="text-orange-400 font-bold">{progressPercent}%</span>
                    </div>

                    <div className="w-full bg-zinc-950/80 rounded-full h-2 p-0.5 border border-zinc-800/80 overflow-hidden relative">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${progressPercent}%` }}
                        transition={{ duration: 0.5, ease: 'easeOut' }}
                        className={`h-full rounded-full bg-gradient-to-r ${progressColor} relative shadow-sm`}
                      >
                        {progressPercent < 100 && (
                          <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
                        )}
                      </motion.div>
                    </div>
                  </div>

                  {/* Items summary */}
                  <div className="py-3 text-xs text-zinc-300 space-y-2">
                    <div className="font-mono text-[11px] text-zinc-500 mb-1">Items Ordered:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {pastOrder.items.map(({ item, qty }) => (
                        <span
                          key={item.id}
                          className="bg-zinc-800/80 text-zinc-300 border border-zinc-700/50 px-2.5 py-1 rounded-lg text-[11px]"
                        >
                          {item.nm} <span className="text-orange-400 font-bold">x{qty}</span>
                        </span>
                      ))}
                    </div>

                    {(pastOrder.orderNotes || pastOrder.customer?.orderNotes) && (
                      <div className="text-[11px] text-amber-300/90 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1.5 rounded-lg font-mono">
                        <span className="font-bold">📝 Notes:</span> "{pastOrder.orderNotes || pastOrder.customer?.orderNotes}"
                      </div>
                    )}

                    {(pastOrder.deliveryInstructions || pastOrder.customer?.deliveryInstructions) && (
                      <div className="text-[11px] text-orange-300/90 bg-orange-500/10 border border-orange-500/20 px-2.5 py-1.5 rounded-lg font-mono">
                        <span className="font-bold">🛵 Delivery:</span> "{pastOrder.deliveryInstructions || pastOrder.customer?.deliveryInstructions}"
                      </div>
                    )}

                    {pastOrder.feedback && (
                      <div className="bg-amber-500/10 border border-amber-500/30 p-2.5 rounded-xl flex items-center justify-between text-xs text-amber-300 font-mono">
                        <div className="flex items-center gap-1.5 truncate pr-2">
                          <span className="text-amber-400 font-bold">
                            {'★'.repeat(pastOrder.feedback.rating)}
                            <span className="text-zinc-600 font-normal">
                              {'★'.repeat(5 - pastOrder.feedback.rating)}
                            </span>
                          </span>
                          {pastOrder.feedback.comment && (
                            <span className="text-zinc-300 truncate italic font-sans font-normal text-[11px]">
                              "{pastOrder.feedback.comment}"
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-amber-400/80 uppercase font-bold flex-shrink-0">
                          Feedback Saved
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60 mt-1 gap-3">
                    <div className="text-[11px] text-zinc-500 truncate max-w-[180px] sm:max-w-xs">
                      📍 {pastOrder.customer.area || pastOrder.customer.address || 'Barasat'}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSelectOrder(pastOrder)}
                        className={`text-xs font-bold px-3 py-1.5 rounded-full border transition-all ${
                          isCurrentView
                            ? 'bg-orange-500 text-white border-orange-500'
                            : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700 border-zinc-700'
                        }`}
                      >
                        Receipt
                      </button>

                      <button
                        onClick={() => onReorder(pastOrder.items)}
                        className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-xs px-3.5 py-1.5 rounded-full transition-all shadow-md shadow-orange-500/10 flex items-center gap-1"
                      >
                        <span>🔁</span>
                        <span>Reorder</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

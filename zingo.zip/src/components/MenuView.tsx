import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MENU } from '../data';

interface MenuViewProps {
  cart: Record<string, number>;
  onAddItem: (id: string) => void;
  onDecItem: (id: string) => void;
  onGoToCart: () => void;
  cartTotal: number;
  cartCount: number;
}

const CATEGORY_EMOJIS: Record<string, string> = {
  'Appetizers': '🍟',
  'Pocket Pizza': '🍕',
  'Burger & Sandwich': '🍔',
  'Beverages': '🧋',
  'Add-ons': '🧀',
};

// Animated Burger Icon for Search Bar
const VegNonVegIcon: React.FC<{ isVeg: boolean; className?: string }> = ({ isVeg, className = '' }) => (
  <div
    className={`w-3.5 h-3.5 border flex items-center justify-center bg-zinc-950/95 rounded-[3px] p-[1px] ${
      isVeg ? 'border-emerald-500' : 'border-red-500'
    } ${className}`}
    title={isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
  >
    <div
      className={`w-1.5 h-1.5 rounded-full ${
        isVeg ? 'bg-emerald-500' : 'bg-red-500'
      }`}
    />
  </div>
);

const AnimatedBurgerIcon: React.FC<{ active: boolean }> = ({ active }) => {
  return (
    <motion.div
      className="relative flex items-center justify-center w-6 h-6 select-none"
      animate={active ? { scale: [1, 1.2, 1.1] } : { scale: 1 }}
      transition={{ duration: 0.25 }}
    >
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="overflow-visible"
      >
        {/* Top Bun with Sesame Seeds */}
        <motion.g
          animate={active ? { y: -3.5, rotate: -16 } : { y: 0, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 450, damping: 18 }}
          style={{ transformOrigin: '4px 10px' }}
        >
          <path
            d="M3 10C3 5.58172 6.58172 2 11 2H13C17.4183 2 21 5.58172 21 10V11H3V10Z"
            fill="#F59E0B"
          />
          {/* Sesame seeds */}
          <ellipse cx="8" cy="5.5" rx="0.8" ry="0.5" fill="#FEF3C7" />
          <ellipse cx="12" cy="4.5" rx="0.8" ry="0.5" fill="#FEF3C7" />
          <ellipse cx="16" cy="6" rx="0.8" ry="0.5" fill="#FEF3C7" />
        </motion.g>

        {/* Lettuce Layer */}
        <motion.path
          d="M2.5 12.5C3.5 11.8 4.5 12.8 5.5 12.2C6.5 11.6 7.5 12.6 8.5 12C9.5 11.4 10.5 12.4 11.5 11.8C12.5 11.2 13.5 12.2 14.5 11.6C15.5 11 16.5 12 17.5 11.4C18.5 10.8 19.5 11.8 21.5 11.5"
          stroke="#22C55E"
          strokeWidth="1.8"
          strokeLinecap="round"
          animate={active ? { scaleX: 1.05 } : { scaleX: 1 }}
          transition={{ duration: 0.2 }}
        />

        {/* Cheese / Tomato Layer */}
        <motion.path
          d="M3.5 13.5H20.5L18.5 15H5.5L3.5 13.5Z"
          fill="#EF4444"
          animate={active ? { y: 0.5 } : { y: 0 }}
        />

        {/* Juicy Patty */}
        <motion.rect
          x="3"
          y="15.2"
          width="18"
          height="3.2"
          rx="1.5"
          fill="#78350F"
          animate={active ? { scaleX: 1.03 } : { scaleX: 1 }}
        />

        {/* Bottom Bun */}
        <motion.path
          d="M4 19.5H20V20.2C20 21.7477 18.7477 23 17.2 23H6.8C5.25228 23 4 21.7477 4 20.2V19.5Z"
          fill="#D97706"
          animate={active ? { y: 1 } : { y: 0 }}
          transition={{ type: 'spring', stiffness: 450, damping: 18 }}
        />
      </svg>
    </motion.div>
  );
};

export const MenuView: React.FC<MenuViewProps> = ({
  cart,
  onAddItem,
  onDecItem,
  onGoToCart,
  cartTotal,
  cartCount,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearchFocused, setIsSearchFocused] = useState<boolean>(false);
  const categoryBarRef = useRef<HTMLDivElement>(null);

  const categories = ['All', ...Array.from(new Set(MENU.map((i) => i.cat)))];

  const handleCategorySelect = (cat: string) => {
    setSelectedCategory(cat);

    // Smoothly center the pill horizontally inside the category bar without scrolling the page
    const pill = document.getElementById(`cat-pill-${cat.replace(/\s+/g, '-')}`);
    if (pill && categoryBarRef.current) {
      const container = categoryBarRef.current;
      const pillRect = pill.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      const scrollLeft =
        container.scrollLeft +
        (pillRect.left - containerRect.left) -
        containerRect.width / 2 +
        pillRect.width / 2;
      container.scrollTo({ left: Math.max(0, scrollLeft), behavior: 'smooth' });
    }
  };

  const searchNormalized = searchQuery.trim().toLowerCase();

  const filteredMenu = MENU.filter((i) => {
    const matchesCategory = selectedCategory === 'All' || i.cat === selectedCategory;
    const matchesQuery =
      !searchNormalized ||
      i.nm.toLowerCase().includes(searchNormalized) ||
      i.ds.toLowerCase().includes(searchNormalized);
    return matchesCategory && matchesQuery;
  });

  const bestSellers = MENU.filter((i) => {
    if (!i.best) return false;
    if (!searchNormalized) return true;
    return (
      i.nm.toLowerCase().includes(searchNormalized) ||
      i.ds.toLowerCase().includes(searchNormalized)
    );
  });

  // Group menu by category when 'All' is selected
  const displayedCategories =
    selectedCategory === 'All'
      ? Array.from(new Set(MENU.map((i) => i.cat)))
      : [selectedCategory];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Compact Hero Banner */}
      <div className="relative rounded-2xl md:rounded-3xl overflow-hidden glass p-4 sm:p-6 md:p-8 flex flex-col justify-center min-h-[140px] md:min-h-[160px] border border-orange-500/20 shadow-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/40 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30 scale-105 transition-transform duration-700"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80')` }}
        />
        
        <div className="relative z-20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="bg-gradient-to-r from-orange-500 to-amber-500 text-white text-[10px] uppercase tracking-widest font-black px-2.5 py-0.5 rounded-full shadow-sm">
                Fired Up &amp; Fresh
              </span>
              <span className="text-zinc-400 text-xs font-mono">📍 Barasat, Kol-124</span>
            </div>
            
            <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight">
              Taste Can't Wait
            </h1>
            
            <p className="text-zinc-300 text-xs sm:text-sm font-medium">
              Pocket pizzas, crunch burgers, and boba tea.
            </p>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 text-[10px] sm:text-[11px] font-mono whitespace-nowrap bg-zinc-900/80 border border-zinc-800 px-3 py-1.5 rounded-xl backdrop-blur-md self-start sm:self-center overflow-x-auto max-w-full scrollbar-none">
            <span className="text-emerald-400 font-bold flex items-center gap-1 flex-shrink-0">⚡ Fast Delivery</span>
            <span className="text-zinc-600 flex-shrink-0">•</span>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <img src="/fssai_logo.svg" alt="FSSAI" className="h-4 sm:h-5 w-auto object-contain" />
              <span className="text-emerald-400 font-bold">Lic. 22826130000506</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search Bar & Filter Controls */}
      <div className="space-y-3">
        <div className="relative flex items-center">
          <div className="absolute left-3.5 pointer-events-none flex items-center justify-center">
            <AnimatedBurgerIcon active={isSearchFocused || Boolean(searchQuery)} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            placeholder="Search menu by name or ingredient (e.g. Fries, Pizza, Boba)..."
            className="w-full bg-zinc-900/90 text-white placeholder-zinc-500 text-xs sm:text-sm pl-12 pr-10 py-3 rounded-2xl border border-zinc-800 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 w-6 h-6 rounded-full flex items-center justify-center text-xs transition-colors"
              title="Clear search"
            >
              ✕
            </button>
          )}
        </div>

        {searchNormalized && (
          <div className="flex items-center justify-between text-xs text-zinc-400 px-1 font-mono">
            <span>
              Found <strong className="text-orange-400">{filteredMenu.length}</strong> {filteredMenu.length === 1 ? 'item' : 'items'} matching "<span className="text-white">{searchQuery}</span>"
            </span>
            <button
              onClick={() => setSearchQuery('')}
              className="text-orange-400 hover:underline text-[11px]"
            >
              Clear filter
            </button>
          </div>
        )}
      </div>

      <div id="menu-content-start" className="scroll-mt-32 sm:scroll-mt-36" />

      {/* Category Filter Pills Bar */}
      <div 
        ref={categoryBarRef}
        className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-zinc-800/60 sticky top-[65px] sm:top-[73px] z-30 bg-[#0a0a0a]/90 backdrop-blur-md py-2"
      >
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat;
          const emoji = CATEGORY_EMOJIS[cat] || (cat === 'All' ? '🍽️' : '✨');
          return (
            <button
              key={cat}
              id={`cat-pill-${cat.replace(/\s+/g, '-')}`}
              onClick={() => handleCategorySelect(cat)}
              className={`px-4 py-2 rounded-full text-xs font-black whitespace-nowrap transition-all flex items-center gap-2 uppercase tracking-wider ${
                isSelected
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-lg shadow-orange-500/25 ring-2 ring-orange-400/30 scale-105'
                  : 'bg-zinc-900/90 text-zinc-400 hover:bg-zinc-800 hover:text-white border border-zinc-800 hover:scale-102'
              }`}
            >
              <span>{emoji}</span>
              <span>{cat}</span>
            </button>
          );
        })}
      </div>

      {/* Best Sellers Section */}
      {selectedCategory === 'All' && bestSellers.length > 0 && (
        <motion.div 
          id="bestsellers-section"
          key={`bestsellers-${selectedCategory}`}
          initial={{ opacity: 0, y: 22, scale: 0.99 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, amount: 0.1 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="space-y-3 pt-1 scroll-mt-32 sm:scroll-mt-36"
        >
          {/* Highlighted Category Banner for Best Sellers */}
          <motion.div 
            initial={{ opacity: 0, x: -16, scale: 0.98 }}
            whileInView={{ opacity: 1, x: 0, scale: 1 }}
            viewport={{ once: false, margin: '-10px' }}
            transition={{ type: 'spring', stiffness: 320, damping: 25 }}
            className={`flex items-center justify-between px-3 py-1.5 rounded-r-xl shadow-sm transition-all duration-300 ${
              selectedCategory === 'All'
                ? 'bg-gradient-to-r from-amber-500/30 via-orange-500/20 to-transparent border-l-4 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.2)]'
                : 'bg-gradient-to-r from-amber-500/20 via-orange-500/10 to-transparent border-l-4 border-amber-500'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <motion.span 
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
                className="text-base sm:text-lg"
              >
                🔥
              </motion.span>
              <div>
                <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                  Trending &amp; Best Sellers
                </h2>
                <p className="text-[10px] text-amber-400/90 font-mono">Customer Favorites in Barasat</p>
              </div>
            </div>
            <span className="text-[9px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30 font-mono">
              {bestSellers.length} ITEMS
            </span>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-2.5">
            {bestSellers.map((item, idx) => {
              const qty = cart[item.id] || 0;
              return (
                <motion.div 
                  key={item.id} 
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25, delay: idx * 0.04 }}
                  whileHover={{ y: -2 }}
                  className="glass-card p-2.5 sm:p-3 rounded-xl flex flex-col justify-between group border border-amber-500/20 hover:border-amber-500/40 transition-all"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-zinc-900/90 border border-zinc-800 flex items-center justify-center text-lg sm:text-xl shadow-inner flex-shrink-0">
                        <span>{item.emoji || (item.veg ? '🥦' : '🍗')}</span>
                        <VegNonVegIcon
                          isVeg={Boolean(item.veg)}
                          className="absolute -top-1 -right-1 z-10 scale-90 shadow-md shadow-black/80"
                        />
                      </div>
                      <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 font-black uppercase tracking-wider">
                        BEST SELLER
                      </span>
                    </div>
                    <div className="info mb-1.5">
                      <div className="nm font-bold text-white text-xs sm:text-sm leading-tight mb-0.5 group-hover:text-amber-400 transition-colors break-words">
                        {item.nm}
                      </div>
                      <div className="ds text-zinc-400 text-[11px] sm:text-xs line-clamp-1 sm:line-clamp-2 leading-tight">
                        {item.ds}
                      </div>
                    </div>
                  </div>

                  <div className="action-wrap flex items-center justify-between pt-1.5 border-t border-zinc-800/60 mt-1">
                    <div className="pr font-serif italic text-amber-400 text-xs sm:text-sm font-bold">
                      ₹{item.pr}
                    </div>
                    {qty === 0 ? (
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        whileHover={{ scale: 1.05 }}
                        onClick={() => onAddItem(item.id)}
                        className="addbtn bg-amber-500/10 hover:bg-amber-500 hover:text-black text-amber-400 border border-amber-500/30 font-black text-[10px] sm:text-xs uppercase tracking-wider px-2.5 py-1 rounded-lg transition-colors shadow-sm"
                      >
                        + ADD
                      </motion.button>
                    ) : (
                      <div className="flex items-center gap-1.5 bg-amber-500 text-black font-black rounded-lg px-1.5 py-0.5">
                        <motion.button
                          whileTap={{ scale: 0.8 }}
                          onClick={() => onDecItem(item.id)}
                          className="w-4 h-4 rounded bg-black/20 hover:bg-black/40 flex items-center justify-center text-[10px]"
                        >
                          -
                        </motion.button>
                        <span className="text-[11px] px-0.5 font-mono">{qty}</span>
                        <motion.button
                          whileTap={{ scale: 0.8 }}
                          onClick={() => onAddItem(item.id)}
                          className="w-4 h-4 rounded bg-black/20 hover:bg-black/40 flex items-center justify-center text-[10px]"
                        >
                          +
                        </motion.button>
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Menu Categories List */}
      {filteredMenu.length === 0 ? (
        <div className="glass p-8 sm:p-12 rounded-3xl text-center space-y-4 border border-zinc-800 my-6">
          <div className="text-4xl">🔍</div>
          <h3 className="text-lg font-bold text-white">No items found</h3>
          <p className="text-zinc-400 text-xs max-w-sm mx-auto">
            We couldn't find any menu items matching "<span className="text-orange-400">{searchQuery}</span>"
            {selectedCategory !== 'All' && <span> in <strong>{selectedCategory}</strong></span>}.
          </p>
          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-5 py-2 rounded-full text-xs uppercase tracking-wider transition-all"
            >
              Reset Filters
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          {displayedCategories.map((category) => {
            const categoryItems = filteredMenu.filter((i) => i.cat === category);
            if (categoryItems.length === 0) return null;
            const emoji = CATEGORY_EMOJIS[category] || '🍽️';

            return (
              <motion.div 
                key={`category-${category}-${selectedCategory}`}
                id={`category-section-${category.replace(/\s+/g, '-')}`}
                initial={{ opacity: 0, y: 24, scale: 0.99 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, amount: 0.08 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-2.5 scroll-mt-32 sm:scroll-mt-36"
              >
                {/* Highlighted Category Section Header Banner */}
                <motion.div 
                  initial={{ opacity: 0, x: -18, scale: 0.98 }}
                  whileInView={{ opacity: 1, x: 0, scale: 1 }}
                  viewport={{ once: false, margin: '-10px' }}
                  transition={{ type: 'spring', stiffness: 320, damping: 25 }}
                  className={`flex items-center justify-between px-3 py-1.5 rounded-r-xl shadow-sm transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-orange-500/35 via-amber-500/20 to-transparent border-l-4 border-amber-400 shadow-[0_0_20px_rgba(249,115,22,0.25)]'
                      : 'bg-gradient-to-r from-orange-500/20 via-orange-500/10 to-transparent border-l-4 border-orange-500'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <motion.span 
                      animate={{ scale: [1, 1.15, 1] }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                      className="text-base sm:text-lg"
                    >
                      {emoji}
                    </motion.span>
                    <div>
                      <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                        {category}
                      </h2>
                      <p className="text-[10px] text-orange-400/90 font-mono">
                        Freshly prepared on order
                      </p>
                    </div>
                  </div>
                  <span className="text-[9px] font-bold text-orange-400 bg-orange-500/20 px-2 py-0.5 rounded-full border border-orange-500/30 font-mono">
                    {categoryItems.length} ITEMS
                  </span>
                </motion.div>

                {/* Items Grid for Category */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 sm:gap-2.5">
                  {categoryItems.map((item, idx) => {
                    const qty = cart[item.id] || 0;
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: idx * 0.03 }}
                        whileHover={{ y: -1 }}
                        className="item glass-card p-2.5 sm:p-3 rounded-xl flex items-center justify-between gap-2.5 transition-all hover:border-zinc-700"
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-grow">
                          <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-zinc-900/90 border border-zinc-800 flex-shrink-0 flex items-center justify-center text-lg sm:text-xl shadow-inner">
                            <span>{item.emoji || (item.veg ? '🥦' : '🍗')}</span>
                            <VegNonVegIcon
                              isVeg={Boolean(item.veg)}
                              className="absolute -top-1 -right-1 z-10 scale-90 shadow-md shadow-black/80"
                            />
                          </div>

                          <div className="info flex-grow min-w-0 pr-1">
                            <div className="mb-0.5">
                              <span className="nm font-bold text-white text-xs sm:text-sm leading-tight break-words">
                                {item.nm}
                              </span>
                            </div>
                            <div className="ds text-zinc-400 text-[11px] sm:text-xs line-clamp-1 leading-tight">
                              {item.ds}
                            </div>
                          </div>
                        </div>

                        <div className="action-wrap flex items-center gap-2 flex-shrink-0 pl-1">
                          <div className="pr font-serif italic text-orange-400 text-xs sm:text-sm font-bold">
                            ₹{item.pr}
                          </div>
                          {qty === 0 ? (
                            <motion.button
                              whileTap={{ scale: 0.85 }}
                              whileHover={{ scale: 1.05 }}
                              onClick={() => onAddItem(item.id)}
                              className="addbtn bg-white/5 hover:bg-orange-500 hover:text-white border border-zinc-700/60 hover:border-orange-500 text-zinc-200 font-bold text-[10px] sm:text-xs uppercase tracking-wider px-2.5 py-1 rounded-lg transition-colors shadow-sm"
                            >
                              ADD
                            </motion.button>
                          ) : (
                            <div className="flex items-center gap-1 bg-orange-500 text-white rounded-lg px-1.5 py-0.5 shadow-md shadow-orange-500/20">
                              <motion.button
                                whileTap={{ scale: 0.8 }}
                                onClick={() => onDecItem(item.id)}
                                className="w-4 h-4 rounded bg-black/20 hover:bg-black/40 flex items-center justify-center font-bold text-[10px]"
                              >
                                -
                              </motion.button>
                              <span className="font-bold text-[11px] px-1 font-mono">{qty}</span>
                              <motion.button
                                whileTap={{ scale: 0.8 }}
                                onClick={() => onAddItem(item.id)}
                                className="w-4 h-4 rounded bg-black/20 hover:bg-black/40 flex items-center justify-center font-bold text-[10px]"
                              >
                                +
                              </motion.button>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Floating Bottom Cart Bar (Sticky when items exist) */}
      <AnimatePresence>
        {cartCount > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 350, damping: 25 }}
            className="sticky bottom-6 z-40"
          >
            <div className="glass p-3.5 rounded-2xl border-orange-500/40 bg-black/90 shadow-2xl flex items-center justify-between max-w-xl mx-auto border backdrop-blur-md">
              <div>
                <div className="text-white font-bold text-sm flex items-center gap-2">
                  <span>🍱 {cartCount} {cartCount === 1 ? 'item' : 'items'} in cart</span>
                </div>
                <div className="text-zinc-400 text-xs font-mono mt-0.5">
                  Subtotal: <span className="text-orange-400 font-bold">₹{cartTotal}</span>
                </div>
              </div>

              <button
                onClick={onGoToCart}
                className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-xs uppercase tracking-widest px-5 py-2.5 rounded-full transition-all shadow-lg shadow-orange-500/20 flex items-center gap-2"
              >
                View Cart &rarr;
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

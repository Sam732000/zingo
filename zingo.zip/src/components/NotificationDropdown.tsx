import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { NotificationItem } from '../types';

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          {/* Backdrop overlay for closing on outside click */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm" 
            onClick={onClose} 
          />

          {/* Centered Compact Notification Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="relative w-full max-w-[280px] z-10 bg-[#121212] border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800/80 bg-zinc-900/80">
              <div className="flex items-center gap-1.5">
                <span className="text-base">🔔</span>
                <h3 className="font-bold text-white text-xs">Notifications</h3>
                {notifications.filter((n) => n.unread).length > 0 && (
                  <span className="bg-orange-500 text-white font-bold text-[9px] px-1.5 py-0.2 rounded-full">
                    {notifications.filter((n) => n.unread).length}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                {notifications.some((n) => n.unread) && (
                  <button
                    onClick={onMarkAllRead}
                    className="text-[9px] font-mono text-orange-400 hover:text-orange-300 transition-colors"
                  >
                    Mark read
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="w-5 h-5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center text-[10px] font-bold transition-colors"
                  aria-label="Close notifications"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* List */}
            <div className="max-h-56 overflow-y-auto divide-y divide-zinc-800/50">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-zinc-500 text-[11px]">
                  No notifications yet.
                </div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className={`p-2.5 flex items-start gap-2.5 transition-colors ${
                      n.unread ? 'bg-orange-500/10' : 'hover:bg-zinc-900/40'
                    }`}
                  >
                    <span className="text-base flex-shrink-0 mt-0.5">{n.icon || '🔔'}</span>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <div className="font-bold text-white text-[11px] truncate">{n.title}</div>
                        <span className="text-[9px] text-zinc-500 font-mono flex-shrink-0">{n.time}</span>
                      </div>
                      <div className="text-zinc-300 text-[10px] leading-snug">{n.message}</div>
                    </div>
                    {n.unread && (
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 flex-shrink-0 mt-1.5 animate-pulse" />
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="p-2 bg-zinc-900/60 border-t border-zinc-800/80 text-center">
              <button
                onClick={onClose}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-[10px] uppercase tracking-wider py-1.5 rounded-lg transition-all"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { StepView } from '../types';

interface StepTrackerProps {
  currentStep: StepView;
  onNavigate: (step: StepView) => void;
}

const STEPS: { key: StepView; label: string }[] = [
  { key: 'menu', label: 'Menu' },
  { key: 'cart', label: 'Cart' },
  { key: 'checkout', label: 'Details' },
  { key: 'payment', label: 'Pay' },
  { key: 'confirm', label: 'Confirmed' },
];

export const StepTracker: React.FC<StepTrackerProps> = ({ currentStep, onNavigate }) => {
  const currentIndex = STEPS.findIndex((s) => s.key === currentStep);

  return (
    <div className="px-6 md:px-12 py-4 bg-[#0d0d0d] border-t border-b border-zinc-800/80 my-4">
      <div className="max-w-xl mx-auto flex items-center justify-between gap-1 relative">
        {STEPS.map((step, idx) => {
          const isActive = step.key === currentStep;
          const isDone = idx < currentIndex;

          return (
            <div 
              key={step.key} 
              className="flex flex-col items-center flex-1 relative z-10 cursor-pointer group"
              onClick={() => {
                if (isDone || isActive) {
                  onNavigate(step.key);
                }
              }}
            >
              <motion.div 
                animate={{
                  scale: isActive ? 1.15 : 1,
                }}
                transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                className={`w-6 h-6 md:w-7 md:h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  isActive 
                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30 ring-4 ring-orange-500/20' 
                    : isDone 
                    ? 'bg-zinc-800 text-orange-400 border border-orange-500/40' 
                    : 'bg-zinc-900 text-zinc-600 border border-zinc-800'
                }`}
              >
                {isDone ? '✓' : idx + 1}
              </motion.div>
              <span 
                className={`text-[10px] md:text-xs uppercase tracking-widest mt-1.5 font-medium transition-colors ${
                  isActive ? 'text-orange-400 font-bold' : isDone ? 'text-zinc-300' : 'text-zinc-600'
                }`}
              >
                {step.label}
              </span>
            </div>
          );
        })}
        
        {/* Animated Progress Line */}
        <div className="absolute top-3 md:top-3.5 left-6 right-6 h-0.5 bg-zinc-800 -z-0">
          <motion.div 
            className="h-full bg-orange-500/60"
            initial={false}
            animate={{ width: `${(currentIndex / (STEPS.length - 1)) * 100}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          />
        </div>
      </div>
    </div>
  );
};


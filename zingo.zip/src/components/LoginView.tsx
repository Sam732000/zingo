import React, { useState } from 'react';
import { motion } from 'motion/react';
import { UserProfile } from '../types';

interface LoginViewProps {
  user: UserProfile;
  onLoginSuccess: (phone: string, name?: string) => void;
  onNavigateToOrders: () => void;
  onGoBack?: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({
  user,
  onLoginSuccess,
  onNavigateToOrders,
  onGoBack,
}) => {
  const [phone, setPhone] = useState(user.phone || '');
  const [name, setName] = useState(user.name || '');
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [simulatedOtp, setSimulatedOtp] = useState('');

  const handleGetOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = phone.trim().replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setError('Please enter a valid 10-digit phone number');
      return;
    }
    setError('');
    const code = '1234';
    setSimulatedOtp(code);
    setOtpSent(true);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.trim() !== '1234' && otp.trim().length !== 4) {
      setError('Invalid OTP code. Please enter 1234.');
      return;
    }
    setError('');
    onLoginSuccess(phone, name || 'Zingo Foodie');
  };

  if (user.isLoggedIn) {
    return (
      <section id="view-login" className="max-w-md mx-auto py-8 px-4">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass p-6 md:p-8 rounded-3xl border border-zinc-800 text-center space-y-6 shadow-2xl"
        >
          <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-3xl mx-auto">
            ✓
          </div>
          <div>
            <h2 className="text-xl font-black text-white uppercase tracking-wide">You are logged in!</h2>
            <p className="text-zinc-400 text-xs font-mono mt-1">
              Phone: <span className="text-orange-400 font-bold">+91 {user.phone}</span>
            </p>
          </div>

          <div className="pt-2 flex flex-col gap-3">
            <button
              onClick={onNavigateToOrders}
              className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs uppercase tracking-widest py-3 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <span>📜</span>
              <span>View Order History</span>
            </button>

            {onGoBack && (
              <button
                onClick={onGoBack}
                className="w-full bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold text-xs uppercase tracking-wider py-2.5 rounded-xl border border-zinc-800 transition-all"
              >
                Back to Menu
              </button>
            )}
          </div>
        </motion.div>
      </section>
    );
  }

  return (
    <section id="view-login" className="max-w-md mx-auto py-8 px-4">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass p-6 md:p-8 rounded-3xl border border-zinc-800 shadow-2xl relative overflow-hidden"
      >
        <div className="text-center mb-6">
          <span className="text-4xl mb-2 block">🔐</span>
          <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-wider">
            Login to your account
          </h2>
          <p className="text-zinc-400 text-xs mt-1">
            Track your live orders, view past order history, and reorder quickly.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs text-center font-mono">
            {error}
          </div>
        )}

        <form onSubmit={otpSent ? handleVerifyOtp : handleGetOtp} className="space-y-4">
          <div>
            <label className="block text-zinc-400 text-xs font-mono mb-1 uppercase tracking-wider">
              Your Name (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Rahul Sharma"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={otpSent}
              className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors disabled:opacity-60"
            />
          </div>

          <div>
            <label className="block text-zinc-400 text-xs font-mono mb-1 uppercase tracking-wider">
              10-Digit Phone Number <span className="text-orange-500">*</span>
            </label>
            <div className="flex items-center gap-2">
              <span className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-3 text-zinc-400 text-sm font-mono">
                +91
              </span>
              <input
                type="tel"
                maxLength={10}
                placeholder="9876543210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                disabled={otpSent}
                className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl px-4 py-3 text-white text-sm font-mono focus:outline-none focus:border-orange-500 transition-colors disabled:opacity-60"
              />
            </div>
          </div>

          {!otpSent ? (
            <div className="space-y-2.5 mt-2">
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs uppercase tracking-widest py-3.5 rounded-xl shadow-lg transition-all"
              >
                Get OTP
              </button>
              {onGoBack && (
                <button
                  type="button"
                  onClick={onGoBack}
                  className="w-full bg-zinc-900/90 hover:bg-zinc-800 text-zinc-400 hover:text-white font-bold text-xs uppercase tracking-wider py-3 rounded-xl border border-zinc-800 transition-all flex items-center justify-center gap-1.5"
                >
                  <span>←</span>
                  <span>Back to Menu</span>
                </button>
              )}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-4 pt-2"
            >
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-center text-xs text-amber-300 font-mono">
                ✨ Demo OTP sent to +91 {phone}: <strong className="text-white text-sm">1234</strong>
              </div>

              <div>
                <label className="block text-zinc-400 text-xs font-mono mb-1 uppercase tracking-wider">
                  4-Digit OTP Code
                </label>
                <input
                  type="text"
                  maxLength={4}
                  placeholder="1234"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl px-4 py-3 text-white text-center text-lg font-mono tracking-widest focus:outline-none focus:border-orange-500 transition-colors"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setOtpSent(false);
                    setOtp('');
                  }}
                  className="w-1/3 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 font-bold text-xs uppercase tracking-wider py-3.5 rounded-xl border border-zinc-800 transition-all"
                >
                  Change
                </button>
                <button
                  type="submit"
                  className="w-2/3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-black text-xs uppercase tracking-widest py-3.5 rounded-xl shadow-lg transition-all"
                >
                  Verify & Login
                </button>
              </div>
            </motion.div>
          )}
        </form>
      </motion.div>
    </section>
  );
};

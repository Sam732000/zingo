import React from 'react';
import { motion } from 'motion/react';
import { Order, UserProfile } from '../types';

interface OrdersViewProps {
  user: UserProfile;
  orders: Order[];
  onSelectOrder: (order: Order) => void;
  onReorder: (items: { item: { id: string }; qty: number }[]) => void;
  onGoToMenu: () => void;
  onGoToLogin: () => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({
  user,
  orders,
  onSelectOrder,
  onReorder,
  onGoToMenu,
  onGoToLogin,
}) => {
  return (
    <section id="view-orders" className="max-w-4xl mx-auto py-6 space-y-6">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 glass p-6 rounded-3xl border border-zinc-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">📜</span>
            <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-wider">
              Your Order History
            </h2>
          </div>
          <p className="text-zinc-400 text-xs">
            {user.isLoggedIn ? (
              <>Logged in as <strong className="text-orange-400">+91 {user.phone}</strong></>
            ) : (
              <>View your recent orders placed in this browser</>
            )}
          </p>
        </div>

        {!user.isLoggedIn ? (
          <button
            onClick={onGoToLogin}
            className="self-start sm:self-center bg-zinc-900 hover:bg-zinc-800 text-orange-400 border border-orange-500/30 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
          >
            🔐 Login to Sync
          </button>
        ) : (
          <div className="bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 rounded-full text-emerald-400 text-xs font-mono font-bold flex items-center gap-1.5 self-start sm:self-center">
            <span>✓ Verified Account</span>
          </div>
        )}
      </div>

      {/* Orders List */}
      {orders.length === 0 ? (
        <div className="glass p-12 rounded-3xl border border-zinc-800 text-center space-y-4">
          <div className="text-5xl">🍱</div>
          <h3 className="text-lg font-bold text-white">No past orders found</h3>
          <p className="text-zinc-400 text-xs max-w-sm mx-auto">
            You haven't placed any orders yet. Check out our menu and treat yourself to delicious food!
          </p>
          <button
            onClick={onGoToMenu}
            className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs uppercase tracking-widest px-6 py-3 rounded-xl shadow-lg transition-all"
          >
            Explore Menu &rarr;
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((ord, idx) => {
            const dateStr = new Date(ord.createdAt).toLocaleDateString('en-IN', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <motion.div
                key={ord.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: idx * 0.04 }}
                className="glass p-5 rounded-2xl border border-zinc-800 hover:border-zinc-700 transition-all space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-orange-400 text-base sm:text-lg">
                        Order #{ord.id}
                      </span>
                      <span
                        className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                          ord.status === 'delivered'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        }`}
                      >
                        {ord.status === 'delivered' ? '✓ Delivered' : `🔥 ${ord.status.toUpperCase()}`}
                      </span>
                    </div>
                    <div className="text-zinc-500 text-xs font-mono mt-0.5">{dateStr}</div>
                  </div>

                  <div className="text-right sm:text-right">
                    <div className="text-zinc-400 text-xs">Total Amount</div>
                    <div className="font-serif italic text-white font-bold text-lg text-amber-400">
                      ₹{ord.total}
                    </div>
                  </div>
                </div>

                {/* Items preview */}
                <div className="space-y-1.5">
                  <div className="text-zinc-400 text-xs font-mono uppercase tracking-wider">
                    Items ({ord.items.length})
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {ord.items.map(({ item, qty }) => (
                      <div
                        key={item.id}
                        className="bg-zinc-900/90 border border-zinc-800 px-3 py-1.5 rounded-xl text-xs text-zinc-200 flex items-center gap-2"
                      >
                        <span>{item.emoji || '🍱'}</span>
                        <span className="font-medium">{item.nm}</span>
                        <span className="text-orange-400 font-bold font-mono">x{qty}</span>
                      </div>
                    ))}
                  </div>

                  {(ord.orderNotes || ord.customer?.orderNotes) && (
                    <div className="text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-xl font-mono mt-1">
                      <span className="font-bold">📝 Kitchen Notes:</span> "{ord.orderNotes || ord.customer?.orderNotes}"
                    </div>
                  )}

                  {(ord.deliveryInstructions || ord.customer?.deliveryInstructions) && (
                    <div className="text-xs text-orange-300 bg-orange-500/10 border border-orange-500/20 px-3 py-1.5 rounded-xl font-mono mt-1">
                      <span className="font-bold">🛵 Delivery Instructions:</span> "{ord.deliveryInstructions || ord.customer?.deliveryInstructions}"
                    </div>
                  )}
                </div>

                {/* Action buttons */}
                <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60">
                  <button
                    onClick={() => onSelectOrder(ord)}
                    className="text-zinc-400 hover:text-white text-xs font-mono underline underline-offset-4 transition-colors"
                  >
                    View Status & Receipt &rarr;
                  </button>

                  <button
                    onClick={() => onReorder(ord.items)}
                    className="bg-amber-500/10 hover:bg-amber-500 hover:text-black text-amber-400 border border-amber-500/30 font-bold text-xs uppercase tracking-wider px-4 py-2 rounded-xl transition-all flex items-center gap-1.5"
                  >
                    <span>🔄</span>
                    <span>Reorder</span>
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </section>
  );
};

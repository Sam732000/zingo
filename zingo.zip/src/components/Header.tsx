import React, { useState } from 'react';
import { FACEBOOK_URL, INSTAGRAM_URL, WA_NUMBER } from '../data';
import { NotificationItem, StepView, UserProfile } from '../types';
import { NotificationDropdown } from './NotificationDropdown';

interface HeaderProps {
  onNavigate: (step: StepView) => void;
  user: UserProfile;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onNavigate,
  user,
  notifications,
  onMarkAllRead,
}) => {
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const unreadCount = notifications.filter((n) => n.unread).length;

  return (
    <header className="flex items-center justify-between px-4 sm:px-8 md:px-12 py-3 md:py-4 border-b border-zinc-800/80 bg-[#0a0a0a]/95 backdrop-blur-md sticky top-0 z-50">
      {/* Brand Logo (Top Left Corner) */}
      <div 
        onClick={() => onNavigate('menu')}
        className="flex items-center gap-3 cursor-pointer select-none group py-0.5"
        title="Zingo - Home"
      >
        <img 
          src="/zingo_logo.svg" 
          alt="Zingo - Taste Can't Wait" 
          className="brand-logo transition-transform group-hover:scale-105 h-9 sm:h-11 w-auto"
        />
      </div>

      {/* Navigation & Action Icons (Top Right Corner) */}
      <div className="flex items-center gap-1.5 sm:gap-3 relative">
        {/* Notification Bell Icon - Only visible after login */}
        {user.isLoggedIn && (
          <div className="relative">
            <button
              onClick={() => setIsNotifOpen(!isNotifOpen)}
              className="text-zinc-300 hover:text-amber-400 p-1.5 rounded-full hover:bg-zinc-800/60 transition-colors relative flex items-center justify-center"
              title="Notifications"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="19" 
                height="19" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
                className={unreadCount > 0 ? 'animate-bell-ring text-amber-400' : ''}
              >
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
              </svg>
              {unreadCount > 0 && (
                <span className="absolute top-0.5 right-0.5 bg-orange-500 text-white font-bold text-[10px] w-3.5 h-3.5 rounded-full flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            <NotificationDropdown
              isOpen={isNotifOpen}
              onClose={() => setIsNotifOpen(false)}
              notifications={notifications}
              onMarkAllRead={onMarkAllRead}
            />
          </div>
        )}

        {/* 1. Login / Profile Option */}
        <button
          onClick={() => onNavigate('login')}
          className={`text-zinc-400 hover:text-orange-400 transition-colors p-1.5 rounded-full hover:bg-zinc-800/50 relative flex items-center justify-center ${
            user.isLoggedIn ? 'text-amber-400 bg-amber-500/10' : ''
          }`}
          title={user.isLoggedIn ? `Logged in: +91 ${user.phone}` : 'Login / Profile'}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="19" 
            height="19" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
            <circle cx="12" cy="7" r="4" />
          </svg>
          {user.isLoggedIn && (
            <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-[#0a0a0a]" />
          )}
        </button>

        {/* 2. Facebook Icon Link */}
        <a
          href={FACEBOOK_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="text-zinc-400 hover:text-blue-500 transition-colors p-1.5 rounded-full hover:bg-zinc-800/50"
          title="Facebook"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="currentColor">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
          </svg>
        </a>

        {/* 3. Instagram Icon Link */}
        <a
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="text-zinc-400 hover:text-pink-500 transition-colors p-1.5 rounded-full hover:bg-zinc-800/50"
          title="Instagram"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
            <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
          </svg>
        </a>

        {/* 4. WhatsApp Icon Link */}
        <a
          href={`https://wa.me/${WA_NUMBER}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-zinc-400 hover:text-emerald-400 transition-colors p-1.5 rounded-full hover:bg-zinc-800/50"
          title="WhatsApp"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.572-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c-.001 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
        </a>
      </div>
    </header>
  );
};

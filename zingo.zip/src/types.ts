export interface MenuItem {
  id: string;
  cat: string;
  veg: boolean;
  nm: string;
  ds: string;
  pr: number;
  best?: boolean;
  img?: string;
  emoji?: string;
}

export interface CartItem {
  item: MenuItem;
  qty: number;
}

export interface CustomerDetails {
  name: string;
  phone: string;
  address: string;
  area: string;
  pin: string;
  city: string;
  district: string;
  state: string;
  orderNotes?: string;
  deliveryInstructions?: string;
}

export interface OrderFeedback {
  rating: number;
  comment: string;
  submittedAt: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  packagingFee: number;
  total: number;
  customer: CustomerDetails;
  method: 'whatsapp' | 'phonepe' | 'razorpay';
  createdAt: string;
  status: 'placed' | 'preparing' | 'out' | 'delivered';
  feedback?: OrderFeedback;
  orderNotes?: string;
  deliveryInstructions?: string;
}

export interface UserProfile {
  phone: string;
  isLoggedIn: boolean;
  name?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  unread: boolean;
  icon?: string;
}

export type StepView = 'menu' | 'cart' | 'checkout' | 'payment' | 'confirm' | 'login' | 'orders';

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StepTracker } from './components/StepTracker';
import { MenuView } from './components/MenuView';
import { CartView } from './components/CartView';
import { CheckoutView } from './components/CheckoutView';
import { PaymentView } from './components/PaymentView';
import { ConfirmView } from './components/ConfirmView';
import { LoginView } from './components/LoginView';
import { OrdersView } from './components/OrdersView';

import {
  MENU,
  PACKAGING_FEE,
  MIN_CART_FOR_FREE_DELIVERY,
  BELOW_MIN_DELIVERY_FEE,
  PER_KM_FEE_BEYOND_RADIUS,
  FREE_DELIVERY_RADIUS_KM,
  KITCHEN_LAT,
  KITCHEN_LNG,
  haversineKm,
  WA_NUMBER,
} from './data';
import { CustomerDetails, NotificationItem, Order, StepView, UserProfile } from './types';

export default function App() {
  const [currentStep, setCurrentStep] = useState<StepView>('menu');
  const [cart, setCart] = useState<Record<string, number>>({});

  useEffect(() => {
    document.documentElement.classList.remove('light');
    document.documentElement.classList.add('dark');
    try {
      localStorage.removeItem('zingo_theme');
    } catch {
      // ignore
    }
  }, []);
  
  // User Profile State
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('zingo_user');
      return saved ? JSON.parse(saved) : { phone: '', isLoggedIn: false, name: '' };
    } catch {
      return { phone: '', isLoggedIn: false, name: '' };
    }
  });

  // Notifications State
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'Order Status Update',
      message: '🔥 Your order #ZNG-0001 is being prepared in the kitchen!',
      time: '10 mins ago',
      unread: true,
      icon: '🔥',
    },
    {
      id: 'notif-[#ZNG-0001]',
      title: 'Out for Delivery',
      message: '🛵 Your order is out for delivery with rider Amit!',
      time: '5 mins ago',
      unread: true,
      icon: '🛵',
    },
    {
      id: 'notif-welcome',
      title: 'Welcome to Zingo!',
      message: '🎉 Taste Can\'t Wait! Enjoy hot and fresh meals delivered in minutes.',
      time: '1 hour ago',
      unread: false,
      icon: '🎉',
    },
  ]);

  const [customerDetails, setCustomerDetails] = useState<CustomerDetails>({
    name: user.name || '',
    phone: user.phone || '',
    address: '',
    area: '',
    pin: '',
    city: 'Barasat',
    district: '',
    state: 'West Bengal',
  });

  const [customerLat, setCustomerLat] = useState<number | null>(null);
  const [customerLng, setCustomerLng] = useState<number | null>(null);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);

  // Persistent Order History state loaded from localStorage
  const [orderHistory, setOrderHistory] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('zingo_order_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [orderSeq, setOrderSeq] = useState(() => {
    try {
      const saved = localStorage.getItem('zingo_order_history');
      const list: Order[] = saved ? JSON.parse(saved) : [];
      return list.length + 1;
    } catch {
      return 1;
    }
  });

  // Handle Login Success
  const handleLoginSuccess = (phone: string, name?: string) => {
    const updatedUser: UserProfile = { phone, isLoggedIn: true, name: name || 'Zingo Foodie' };
    setUser(updatedUser);
    try {
      localStorage.setItem('zingo_user', JSON.stringify(updatedUser));
    } catch (e) {
      console.error(e);
    }
    // Update customer phone in details if empty
    setCustomerDetails((prev) => ({
      ...prev,
      phone: phone || prev.phone,
      name: name || prev.name,
    }));
    handleNavigate('orders');
  };

  // Mark all notifications read
  const handleMarkAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  // Add Item to Cart
  const handleAddItem = (id: string) => {
    setCart((prev) => ({
      ...prev,
      [id]: (prev[id] || 0) + 1,
    }));
  };

  // Decrease Item from Cart
  const handleDecItem = (id: string) => {
    setCart((prev) => {
      const copy = { ...prev };
      if (copy[id]) {
        copy[id] -= 1;
        if (copy[id] <= 0) delete copy[id];
      }
      return copy;
    });
  };

  // Cart Calculations
  const cartItemIds = Object.keys(cart);
  const cartCount = Object.values(cart).reduce((a: number, b: number) => a + b, 0);
  const cartSubtotal = cartItemIds.reduce((sum: number, id: string) => {
    const item = MENU.find((m) => m.id === id);
    return sum + (item ? item.pr * (cart[id] || 0) : 0);
  }, 0);

  // Distance & Delivery Fee Calculation
  const getDistanceKm = (): number | null => {
    if (customerLat === null || customerLng === null) return null;
    return haversineKm(KITCHEN_LAT, KITCHEN_LNG, customerLat, customerLng);
  };

  const getDeliveryFee = (): number => {
    const dist = getDistanceKm();
    if (dist === null) {
      return cartSubtotal >= MIN_CART_FOR_FREE_DELIVERY ? 0 : BELOW_MIN_DELIVERY_FEE;
    }
    if (dist <= FREE_DELIVERY_RADIUS_KM) {
      return cartSubtotal >= MIN_CART_FOR_FREE_DELIVERY ? 0 : BELOW_MIN_DELIVERY_FEE;
    }
    const extraKm = Math.ceil(dist - FREE_DELIVERY_RADIUS_KM);
    return extraKm * PER_KM_FEE_BEYOND_RADIUS;
  };

  const deliveryFee = getDeliveryFee();
  const orderTotal = cartSubtotal + deliveryFee + PACKAGING_FEE;

  // Navigation Helper
  const handleNavigate = (step: StepView) => {
    setCurrentStep(step);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Proceed to Payment handler
  const handleProceedToPayment = (
    details: CustomerDetails,
    lat: number | null,
    lng: number | null
  ) => {
    setCustomerDetails(details);
    setCustomerLat(lat);
    setCustomerLng(lng);
    handleNavigate('payment');
  };

  // Confirm Order handler with LocalStorage persistence
  const handleConfirmOrder = async (method: 'whatsapp' | 'phonepe' | 'razorpay') => {
    const nextId = 'ZNG-' + String(orderSeq).padStart(4, '0');
    setOrderSeq((prev) => prev + 1);

    const items = cartItemIds.map((id) => ({
      item: MENU.find((m) => m.id === id)!,
      qty: cart[id],
    }));

    const newOrder: Order = {
      id: nextId,
      items,
      subtotal: cartSubtotal,
      deliveryFee,
      packagingFee: PACKAGING_FEE,
      total: orderTotal,
      customer: customerDetails,
      method,
      createdAt: new Date().toISOString(),
      status: 'placed',
      orderNotes: customerDetails.orderNotes,
      deliveryInstructions: customerDetails.deliveryInstructions,
    };

    setLastOrder(newOrder);

    // Add new notification for the order
    setNotifications((prev) => [
      {
        id: `notif-${nextId}`,
        title: `Order Placed (#${nextId})`,
        message: `🔥 Your order for ₹${orderTotal} has been received and sent to kitchen!`,
        time: 'Just now',
        unread: true,
        icon: '🍱',
      },
      ...prev,
    ]);

    // Save to order history in state and LocalStorage
    const updatedHistory = [newOrder, ...orderHistory.filter((o) => o.id !== newOrder.id)];
    setOrderHistory(updatedHistory);
    try {
      localStorage.setItem('zingo_order_history', JSON.stringify(updatedHistory));
    } catch (e) {
      console.error('Failed to save order history to localStorage:', e);
    }

    if (method !== 'whatsapp') {
      handleNavigate('confirm');
    } else {
      // Build WhatsApp message and open URL
      const itemLines = items
        .map(({ item, qty }) => `• ${item.nm} x${qty} — ₹${item.pr * qty}`)
        .join('\n');

      let notesSection = '';
      if (customerDetails.orderNotes) {
        notesSection += `\n📝 Order Notes: ${customerDetails.orderNotes}`;
      }
      if (customerDetails.deliveryInstructions) {
        notesSection += `\n🛵 Delivery Instructions: ${customerDetails.deliveryInstructions}`;
      }

      const msg = `Hi Zingo! I'd like to place an order (#${nextId}):\n\n${itemLines}\n\nDelivery Fee: ₹${deliveryFee}\nPackaging: ₹${PACKAGING_FEE}\nTotal Amount: ₹${orderTotal}\n\nName: ${customerDetails.name}\nPhone: ${customerDetails.phone}\nAddress: ${customerDetails.address}, ${customerDetails.area} - ${customerDetails.pin}${notesSection}`;

      const waUrl = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;
      window.open(waUrl, '_blank');
      handleNavigate('confirm');
    }
  };

  // Start a New Order
  const handleNewOrder = () => {
    setCart({});
    setLastOrder(null);
    handleNavigate('menu');
  };

  // Reorder items from history
  const handleReorder = (items: { item: { id: string }; qty: number }[]) => {
    const newCart: Record<string, number> = {};
    items.forEach(({ item, qty }) => {
      newCart[item.id] = (newCart[item.id] || 0) + qty;
    });
    setCart(newCart);
    handleNavigate('cart');
  };

  // Clear order history
  const handleClearHistory = () => {
    setOrderHistory([]);
    setLastOrder(null);
    try {
      localStorage.removeItem('zingo_order_history');
    } catch (e) {
      console.error(e);
    }
  };

  // Save order feedback and persist to localStorage
  const handleSaveFeedback = (orderId: string, rating: number, comment: string) => {
    const feedback = {
      rating,
      comment,
      submittedAt: new Date().toISOString(),
    };

    const updatedHistory = orderHistory.map((o) =>
      o.id === orderId ? { ...o, feedback } : o
    );
    setOrderHistory(updatedHistory);

    if (lastOrder && lastOrder.id === orderId) {
      setLastOrder({ ...lastOrder, feedback });
    }

    try {
      localStorage.setItem('zingo_order_history', JSON.stringify(updatedHistory));
    } catch (e) {
      console.error('Failed to save order feedback to localStorage:', e);
    }
  };

  return (
    <div className="bg-[#0a0a0a] text-zinc-100 font-sans min-h-screen flex flex-col selection:bg-orange-500 selection:text-white">
      {/* Header */}
      <Header
        onNavigate={handleNavigate}
        user={user}
        notifications={notifications}
        onMarkAllRead={handleMarkAllRead}
      />

      {/* Main Content Area */}
      <main className="flex-grow p-4 sm:p-6 md:p-8 max-w-6xl mx-auto w-full">
        {currentStep === 'menu' && (
          <MenuView
            cart={cart}
            onAddItem={handleAddItem}
            onDecItem={handleDecItem}
            onGoToCart={() => handleNavigate('cart')}
            cartTotal={cartSubtotal}
            cartCount={cartCount}
          />
        )}

        {currentStep === 'cart' && (
          <CartView
            cart={cart}
            onAddItem={handleAddItem}
            onDecItem={handleDecItem}
            onNavigate={handleNavigate}
            deliveryFee={deliveryFee}
            distanceKm={getDistanceKm()}
          />
        )}

        {currentStep === 'checkout' && (
          <CheckoutView
            user={user}
            onProceedToPayment={handleProceedToPayment}
            onNavigate={handleNavigate}
          />
        )}

        {currentStep === 'payment' && (
          <PaymentView
            orderTotal={orderTotal}
            onConfirmOrder={handleConfirmOrder}
            onNavigate={handleNavigate}
          />
        )}

        {currentStep === 'confirm' && (
          <ConfirmView
            order={lastOrder || (orderHistory.length > 0 ? orderHistory[0] : null)}
            orderHistory={orderHistory}
            onNewOrder={handleNewOrder}
            onSelectOrder={(selOrder) => setLastOrder(selOrder)}
            onReorder={handleReorder}
            onClearHistory={handleClearHistory}
            onSaveFeedback={handleSaveFeedback}
          />
        )}

        {currentStep === 'login' && (
          <LoginView
            user={user}
            onLoginSuccess={handleLoginSuccess}
            onNavigateToOrders={() => handleNavigate('orders')}
            onGoBack={() => handleNavigate('menu')}
          />
        )}

        {currentStep === 'orders' && (
          <OrdersView
            user={user}
            orders={orderHistory}
            onSelectOrder={(selOrder) => {
              setLastOrder(selOrder);
              handleNavigate('confirm');
            }}
            onReorder={handleReorder}
            onGoToMenu={() => handleNavigate('menu')}
            onGoToLogin={() => handleNavigate('login')}
          />
        )}
      </main>

      {/* Step Tracker (Single Line Bottom Navigation) */}
      <StepTracker currentStep={currentStep} onNavigate={handleNavigate} />

      {/* Footer styled according to Sophisticated Dark Theme */}
      <footer className="px-6 md:px-12 py-8 border-t border-zinc-800/50 bg-[#0a0a0a] mt-auto">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-zinc-500 font-mono">
          <div className="flex items-center gap-2">
            <span>© 2026 Zingo</span>
            <span>•</span>
            <span>Noapara, Barasat, Kol-124</span>
          </div>

          <div className="flex gap-6 uppercase tracking-wider text-[10px]">
            <a href="#" className="hover:text-zinc-300 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-zinc-300 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-zinc-300 transition-colors">Delivery Areas</a>
            <button 
              onClick={() => handleNavigate('login')}
              className="hover:text-zinc-300 transition-colors uppercase"
            >
              🔐 {user.isLoggedIn ? 'Account' : 'Login'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
